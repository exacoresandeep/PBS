<?php

namespace App\Http\Controllers\Api;
use Yajra\DataTables\Facades\DataTables;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Lead;
use App\Models\Order;
use App\Models\LeadFollowUp;
use App\Models\OrderItem;
use App\Models\TripRoute;
use App\Models\Employee;
use App\Models\Dealer;
use App\Models\ProductType;
use App\Models\InfluencerVisit;
use App\Models\InfluencerVisitFollowUp;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Carbon\Carbon;
use App\Services\FirebasePushService;
use App\Exports\AllLeadExport;
use Maatwebsite\Excel\Facades\Excel;

class LeadController extends Controller
{
    //
    public function index(Request $request)
    {
        try {
            $user = Auth::user();
            if ($user !== null) {
                $leads = Lead::with(['customerType', 'district', 'tripRoute'])
                    //                            ->where('created_by', $user->id)
                    ->orderBy('created_at', 'desc')
                    ->get();

                if ($leads->isEmpty()) {
                    return response()->json([
                        'success' => true,
                        'statusCode' => 200,
                        'message' => 'No leads found',
                        'data' => [],
                    ], 200);
                }

                $formattedLeads = $leads->map(function ($lead) {
                    return [
                        'lead_id' => $lead->id,
                        'status' => $lead->status,
                        'customer_name' => $lead->customer_name,
                        'customer_type' => $lead->customerType ? [
                            'id' => $lead->customerType->id,
                            'name' => $lead->customerType->name,
                        ] : null,
                        'district' => $lead->district ? [
                            'id' => $lead->district->id,
                            'name' => $lead->district->name,
                        ] : null,
                        'latitude' => $lead->latitude,
                        'longitude' => $lead->longitude,
                        'route_name' => $lead->tripRoute ? $lead->tripRoute->route_name : null,
                        'location_name' => $lead->location ? $lead->location : null,
                        'created_at' => $lead->created_at->format('d/M/Y h:i A'),
                        'updated_at' => $lead->updated_at->format('d/M/Y h:i A'),
                        'follow_up_date' => $lead->follow_up_date,
                    ];
                });

                return response()->json([
                    'success' => true,
                    'statusCode' => 200,
                    'message' => 'Leads retrieved successfully!',
                    'data' => $formattedLeads,
                ], 200);
            } else {
                return response()->json([
                    'success' => false,
                    'statusCode' => 401,
                    'message' => 'Unauthorized access.',
                ], 401);
            }
        } catch (Exception $e) {
            return response()->json([
                'success' => false,
                'statusCode' => 500,
                'message' => $e->getMessage(),
            ], 500);
        }
    }

    public function store(Request $request)
    {
        try {
            $validatedData = $request->validate([
                'customer_type' => 'required|exists:customer_types,id',
                'customer_name' => 'required|string',
                'phone' => 'required|string',
                'address' => 'required|string',
                'city' => 'required|string',
                'location' => 'required|string',
                'district_id' => 'required|exists:districts,id',
                'assigned_route_id' => 'required|exists:assigned_routes,id',
                'ace_code' => 'nullable',
                'mitr_code' => 'nullable',
                'latitude' => 'required|string',
                'longitude' => 'required|string',
            ]);
            $existingLead = Lead::where('phone', $request->phone)->first();
            if ($existingLead) {
                return response()->json([
                    'success' => false,
                    'statusCode' => 400,
                    'message' => 'Lead with the same phone number already exists!',
                    'data' => [],
                ], 400);
            }


            $validatedData['created_by'] = Auth::id();

            $lead = Lead::create($validatedData);
            $leadData = [
                'customer_type' => $lead->customerType->name ?? null,
                'customer_name' => $lead->customer_name,
                'address' => $lead->address,
                'city' => $lead->city,
                'sub_location' => $lead->location,
                'phone' => $lead->phone,
                'district' => $lead->district->name ?? null,
                'assigned_route_id' => $lead->assigned_route_id,
                'status' => 'Opened',
                'ace_code' => $lead->ace_code,
                'mitr_code' => $lead->mitr_code,
                'latitude' => $lead->latitude,
                'longitude' => $lead->longitude,
                        
                'created_at' => $lead->created_at->format('Y-m-d H:i:s'),

            ];
            return response()->json([
                'success' => true,
                'statusCode' => 200,
                'message' => 'Lead created successfully!',
                'data' => $leadData,
            ], 200);
        } catch (Exception $e) {
            return response()->json([
                'success' => false,
                'statusCode' => 500,
                'message' => $e->getMessage(),
            ], 500);
        }
    }

    public function show($leadId)
    {
        try {
            $employee = Auth::user();
            $allowedEmployeeTypes = [];

            switch ($employee->employee_type_id) {
                case 1:
                    $allowedEmployeeTypes = [1];
                    break;
                case 2:
                    $allowedEmployeeTypes = [2];
                    break;
                case 3:
                    $allowedEmployeeTypes = [1, 2, 3];
                    break;
                case 4:
                    $allowedEmployeeTypes = [1, 2, 3, 4];
                    break;
                case 5:
                    $allowedEmployeeTypes = [1, 2, 3, 4, 5];
                    break;
                default:
                    return response()->json([
                        'success' => false,
                        'statusCode' => 403,
                        'message' => "Unauthorized access.",
                    ], 403);
            }

            $lead = Lead::with(['customerType', 'district', 'assignRoute', 'dealer', 'orders.orderItems.product', 'orders.paymentTerm', 'orders.dealer', 'followUps'])
                ->whereHas('createdBy', function ($query) use ($allowedEmployeeTypes) {
                    $query->whereIn('employee_type_id', $allowedEmployeeTypes);
                })
                ->findOrFail($leadId);
            if (!$lead) {
                return response()->json([
                    'success' => false,
                    'statusCode' => 404,
                    'message' => 'Lead not found!',
                ], 404);
            }
            if ($lead->notification_status == 'pending' && $lead->created_by == $employee->id) {
                $lead->update(['notification_status' => 'opened']);
            }
            $leadWonOrders = $lead->orders->where('source', 'lead_won');
            $relatedLeads = Lead::with('orders.orderItems')
                ->where('lead_chain_id', $lead->lead_chain_id)
                ->get();
            $wonVolume = $relatedLeads->flatMap(function ($relatedLead) {
                return $relatedLead->orders->flatMap(function ($order) {
                    return $order->orderItems;
                });
            })->sum('total_quantity');
            $lostVolume = $relatedLeads->sum(function ($relatedLead) {
                return $relatedLead->lost_volume ?? 0;
            });
            if ((float) $lead->total_quantity === 0.0) {
                $wonVolume = 0;
                $lostVolume = 0;
            }
            $paymentTerms = $leadWonOrders
                ->pluck('paymentTerm')
                ->unique('id')
                ->filter()
                ->map(function ($paymentTerm) {
                    return [
                        'id' => $paymentTerm->id,
                        'name' => $paymentTerm->name,
                    ];
                })
                ->values();
            $paymentTerms = $paymentTerms->count() === 1 ? $paymentTerms->first() : ($paymentTerms->isEmpty() ? null : $paymentTerms);

            $dealers = $leadWonOrders
                ->pluck('dealer')
                ->unique('id')
                ->filter()
                ->map(function ($dealer) {
                    return [
                        'id' => $dealer->id,
                        'name' => $dealer->dealer_name,
                    ];
                })
                ->values();
            $dealers = $dealers->count() === 1 ? $dealers->first() : ($dealers->isEmpty() ? null : $dealers);
            $latestOrder = $leadWonOrders->last();
            $attachments = [
                'attachment' => $latestOrder && $latestOrder->attachment ? $latestOrder->attachment : null,

            ];
            $firstLead = Lead::where('lead_chain_id', $lead->lead_chain_id)
                ->orderBy('created_at', 'asc')
                ->first();

            $initialTotalVolume = $firstLead ? (float) $firstLead->total_volume : (float) $lead->total_volume;
            $leadData = [
                'id' => $lead->id,
                'customer_type' => $lead->customerType ? [
                    'id' => $lead->customerType->id,
                    'name' => $lead->customerType->name,
                ] : null,
                'customer_name' => $lead->customer_name,
                'city' => $lead->city,
                'location' => $lead->location,
                'phone' => $lead->phone,
                'address' => $lead->address,
                'district' => $lead->district ? [
                    'id' => $lead->district->id,
                    'name' => $lead->district->name,
                ] : null,
                'trip_route' => $lead->assignRoute ? [
                    'id' => $lead->assignRoute->id,
                    'route_name' => $lead->assignRoute->route_name,
                    'location_name' => $lead->assignRoute->locations,
                ] : null,
                'type_of_visit' => $lead->type_of_visit,
                'construction_type' => $lead->construction_type,
                'construction_type_name' => $lead->construction_type_name,
                'stage_of_construction' => $lead->stage_of_construction,
                'follow_up_date' => $lead->follow_up_date,
                'lead_score' => $lead->lead_score,
                'lead_source' => $lead->lead_source,
                'source_name' => $lead->source_name,
                'total_volume' => (float) $initialTotalVolume,
                'total_quantity' => (float) $lead->total_quantity,
                'current_deal_volume' => (float) $initialTotalVolume - $wonVolume - $lostVolume,
                //'current_deal_volume' => (float) $lead->total_deal_volume - $wonVolume - $lostVolume,
                // 'current_deal_volume' => (float) $lead->current_deal_volume,
                'won_volume' => (float) $wonVolume,
                'lost_v' => (float) $lostVolume,
                // 'total_deal_volume' => (float) $wonVolume + $lostVolume + $lead->current_deal_volume,
                // 'volume' => (float) $lead->previous_quantity,
                'previous_brand' => $lead->previous_brand,
                'brand_name' => $lead->brand_name,
                'previous_brand_quantity' => (float) $lead->previous_brand_quantity,
                'customer_meet' => $lead->customer_meet,
                'ring_test' => $lead->ring_test,
                'further_requirement' => $lead->further_requirement,
                'further_volume' => (float) $lead->further_volume,
                'lost_volume' => (float) $lead->lost_volume,
                'lost_to_competitor' => $lead->lost_to_competitor,
                'competitor_name' => $lead->competitor_name,
                'reason_for_lost' => $lead->reason_for_lost,
                'status' => $lead->status,
                'ace_code' => $lead->ace_code,
                'mitr_code' => $lead->mitr_code,
                'latitude' => $lead->latitude,
                'longitude' => $lead->longitude,
                'dealer' => $lead->dealer ? [
                    'id' => $lead->dealer->id,
                    'name' => $lead->dealer->dealer_name,
                ] : null,
                'created_by' => $lead->created_by,
                'created_at' => $lead->created_at->format('d/M/Y'),
                'updated_at' => $lead->updated_at,
                'follow_ups' => $lead->followUps->map(function ($followUp) {
                    return [
                        'id' => $followUp->id,
                        'follow_up_date' => $followUp->follow_up_date,
                        'follow_up_reason' => $followUp->reason,

                    ];
                })->values(),

                'payment_terms' => $paymentTerms,
                'dealers' => $dealers,
                'attachment' => $attachments['attachment'],
                'orders' => $leadWonOrders->map(function ($order) {
                    return [
                        'id' => $order->id,
                        'total_amount' => $order->total_amount,
                        'status' => $order->status,
                        'billing_date' => $order->billing_date,
                        'credit_days'  => $order->credit_days,
                        'order_items' => $order->orderItems->map(function ($item) {
                            $details = is_array($item->product_details)
                                ? $item->product_details
                                : json_decode($item->product_details, true);

                            $totalPieces = 0;
                            $totalTon = 0;

                            if (is_array($details)) {
                                foreach ($details as $d) {
                                    $pieces = isset($d['pieces']) ? (float) $d['pieces'] : 0;
                                    $tonnage = isset($d['tonnage']) ? (float) $d['tonnage'] : 0;

                                    $totalPieces += $pieces;
                                    $totalTon += ($pieces * $tonnage);
                                }
                            }

                            return [
                                'id' => $item->id,
                                'product_id' => $item->product_id,
                                'product_name' => $item->product ? $item->product->product_name : null,
                                'product_code' => $item->product ? $item->product->product_code : null,
                                'total_quantity' => $item->total_quantity,
                                'balance_quantity' => (float) $item->balance_quantity,
                                'product_details' => $details,
                                'total_pieces' => $totalPieces,
                                'total_ton' => $totalTon,
                            ];
                        })->values(),
                    ];
                })->values(),

            ];

            return response()->json([
                'success' => true,
                'statusCode' => 200,
                'message' => 'Lead retrieved successfully!',
                'data' => $leadData,
            ], 200);
        } catch (Exception $e) {
            return response()->json([
                'success' => false,
                'statusCode' => 500,
                'message' => $e->getMessage(),
            ], 500);
        }
    }

    public function searchLead(Request $request)
    {

        try {
            $user = Auth::user();

            if (!$user) {
                return response()->json([
                    'success' => false,
                    'statusCode' => 401,
                    'message' => 'Unauthorized access.',
                ], 401);
            }

            $query = Lead::with(['customerType', 'district', 'tripRoute'])
                ->where('created_by', $user->id);

            if ($request->has('status')) {
                $status = $request->input('status');

                if (is_string($status)) {
                    $status = explode(',', $status);
                }

                $query->whereIn('status', $status);
            }

            if ($request->has('customer_name')) {
                $query->where('customer_name', 'like', '%' . $request->input('customer_name') . '%');
            }

            $leads = $query->orderBy('customer_name', 'asc')->get();

            if ($leads->isEmpty()) {
                return response()->json([
                    'success' => true,
                    'statusCode' => 200,
                    'message' => 'No leads found.',
                    'data' => [],
                ], 200);
            }

            $formattedLeads = $leads->map(function ($lead) {
                return [
                    'id' => $lead->id,
                    'status' => $lead->status,
                    'customer_name' => $lead->customer_name,
                    'customer_type' => $lead->customerType ? [
                        'id' => $lead->customerType->id,
                        'name' => $lead->customerType->name,
                    ] : null,
                    'district' => $lead->district ? [
                        'id' => $lead->district->id,
                        'name' => $lead->district->name,
                    ] : null,
                    'route_name' => $lead->tripRoute->route_name ?? null,
                    'location' => $lead->location,
                    'ace_code' => $lead->ace_code,
                    'mitr_code' => $lead->mitr_code,
                    'latitude' => $lead->latitude,
                        'longitude' => $lead->longitude,
                    //  'created_at' => $lead->created_at->format('d/M/Y h:i A'),
                    'created_at' => ($lead->status === 'Follow Up' || $lead->status === 'Won' || $lead->status === 'Lost')
                        ? optional($lead->updated_at)->format('d/m/Y h:i A')
                        : optional($lead->created_at)->format('d/m/Y h:i A'),
                    'updated_at' => $lead->updated_at,
                ];
            });

            return response()->json([
                'success' => true,
                'statusCode' => 200,
                'message' => 'Filtered leads retrieved successfully!',
                'data' => $formattedLeads,
            ], 200);
        } catch (Exception $e) {
            return response()->json([
                'success' => false,
                'statusCode' => 500,
                'message' => $e->getMessage(),
            ], 500);
        }
    }

    public function updateLead(Request $request, $leadId, FirebasePushService $fcm)
    {
        try {

            $validatedData = $request->validate([
                'type_of_visit' => 'required|string',
                'construction_type' => 'required|string',
                'construction_type_name' => 'nullable|string',
                'stage_of_construction' => 'required|string',
                'follow_up_date' => 'nullable|date',
                'follow_up_reason' => 'nullable|string',
                'lead_score' => 'required|string',
                'lead_source' => 'required|string',
                'source_name' => 'nullable|string',
                // 'total_quantity' => 'required|numeric',
                'total_volume' => 'required|numeric',
                'status' => 'required|in:Opened,Follow Up,Won,Lost',
                'dealer_id' => 'nullable|numeric',
                'ace_code' => 'nullable',
                'mitr_code' => 'nullable',

                'lost_details.lost_volume' => 'required_if:status,Lost|nullable|numeric',
                'lost_details.lost_to_competitor' => 'required_if:status,Lost|nullable|string',
                'lost_details.competitor_name' => 'nullable|string',
                'lost_details.reason_for_lost' => 'required_if:status,Lost|nullable|string',
                'previous_brand' => 'required_if:status,Lost|nullable|string',
                'brand_name' => 'nullable|string',
                'previous_brand_quantity' => 'required_if:status,Lost|nullable|numeric',
                'customer_meet' => 'required_if:status,Lost|nullable|in:Yes,No',
                'ring_test' => 'required_if:status,Lost|nullable|in:Yes,No',
                'further_requirement' => 'required_if:status,Lost|nullable|in:Yes,No',
                'further_volume' => 'required_if:status,Lost|nullable|numeric',

                'order_details.customer_type_id' => 'required_if:status,Won|nullable|exists:customer_types,id',
                'order_details.dealer_id' => 'required_if:status,Won|exists:dealers,id',
                'order_details.dealer_flag_order' => 'nullable|numeric',
                'order_details.payment_terms_id' => 'required_if:status,Won|nullable|exists:payment_terms,id',
                'order_details.total_amount' => 'required_if:status,Won|nullable|numeric',
                'order_details.order_items' => 'required_if:status,Won|nullable|array',
                'order_details.order_items.*.product_id' => 'required_with:order_details.order_items|exists:products,id',
                'order_details.order_items.*.total_quantity' => 'required_with:order_details.order_items|numeric',
                'order_details.order_items.*.balance_quantity' => 'required_with:order_details.order_items|numeric',
                'order_details.order_items.*.product_details' => 'nullable|array',
                'order_details.attachment' => 'nullable|array',
                'order_details.attachment.*' => 'nullable|string',
            ]);

            $lead = Lead::where('id', $leadId)
                ->where('created_by', Auth::id())
                ->firstOrFail();

            if (!$lead->lead_chain_id) {
                $lead->update(['lead_chain_id' => (string) Str::uuid()]);
            }

            $firstLead = Lead::where('lead_chain_id', $lead->lead_chain_id)
                ->orderBy('created_at', 'asc')
                ->first();

            $totalDealVolume = $firstLead ? (float) $firstLead->total_volume : (float) $lead->total_volume;
            $skipVolumeCheck = empty($totalDealVolume);
            DB::beginTransaction();

            $notification_status = $request->status === 'Follow Up' ? 'approved' : 'pending';

            if ($request->status === 'Follow Up') {

                LeadFollowUp::create([
                    'lead_id' => $lead->id,
                    'follow_up_date' => $request->follow_up_date,
                    'reason' => $request->follow_up_reason,
                    'notification_status' => 'pending',
                    'created_by' => Auth::id(),
                ]);

                $lead->update(['follow_up_date' => $request->follow_up_date]);
            }

            $leadData = [
                'type_of_visit' => $request->type_of_visit,
                'construction_type' => $request->construction_type,
                'construction_type_name' => $request->construction_type_name,
                'stage_of_construction' => $request->stage_of_construction,
                'follow_up_date' => $request->follow_up_date,
                'lead_score' => $request->lead_score,
                'lead_source' => $request->lead_source,
                'source_name' => $request->source_name,
                'total_quantity' => $request->total_volume,
                'total_deal_volume' => $totalDealVolume,
                'total_volume' => $request->total_volume,
                'status' => $request->status,
                'notification_status' => $notification_status,
                'updated_by' => Auth::id(),
            ];

            if (!empty($request->dealer_id)) {
                $leadData['dealer_id'] = $request->dealer_id;
            }


            if ($request->status === 'Lost' && !empty($request->lost_details)) {
                $lost = $request->lost_details;

                $leadData = array_merge($leadData, [
                    'lost_volume' => $lost['lost_volume'] ?? null,
                    'lost_to_competitor' => $lost['lost_to_competitor'] ?? null,
                    'competitor_name' => $lost['competitor_name'] ?? null,
                    'reason_for_lost' => $lost['reason_for_lost'] ?? null,
                    'previous_brand' => $request->previous_brand ?? null,
                    'brand_name' => $request->brand_name ?? null,
                    'previous_brand_quantity' => $request->previous_brand_quantity ?? null,
                    'customer_meet' => $request->customer_meet ?? null,
                    'ring_test' => $request->ring_test ?? null,
                    'further_requirement' => $request->further_requirement ?? null,
                    'further_volume' => $request->further_volume ?? null,
                ]);
            }
            $oldStatus = $lead->status;
            $lead->update($leadData);

            $order = null;

            if ($request->status === 'Won' && !empty($request->order_details)) {

                $orderDetails = $request->order_details;

                $order = Order::create([
                    'customer_type_id' => $orderDetails['customer_type_id'],
                    'lead_id' => $lead->id,
                    'dealer_id' => $orderDetails['dealer_id'] ?? null,
                    'dealer_flag_order' => $orderDetails['dealer_flag_order'] ?? "0",
                    'payment_terms_id' => $orderDetails['payment_terms_id'],
                    'credit_days' => $orderDetails['credit_days'] ?? null,
                    'total_amount' => (float)$orderDetails['total_amount'],
                    'billing_date' => now()->format('Y-m-d'),
                    'latitude' => $request->latitude,
                    'longitude' => $request->longitude,
                    'status' => 'Pending',
                    'source' => 'lead_won',
                    'created_by' => Auth::id(),
                    'attachment' => $orderDetails['attachment'] ?? [],
                    'product_id' => $orderDetails['order_items'][0]['product_id'] ?? null, // SAME AS store()
                ]);

                foreach ($orderDetails['order_items'] as $item) {

                    $totalQuantity = 0;
                    $productDetailsArray = [];

                    if (!empty($item['product_details'])) {

                        foreach ($item['product_details'] as $pd) {

                            if (!empty($pd['pieces'])) {
                                $totalQuantity += (float)$pd['pieces'];
                            } else if (!empty($pd['quantity'])) {
                                $totalQuantity += (float)$pd['quantity'];
                            }

                            $typeName = \App\Models\ProductType::where('id', $pd['product_type_id'])
                                ->value('type_name');

                            $pd['type_name'] = $typeName;

                            $productDetailsArray[] = $pd;
                        }
                    } else {
                        $totalQuantity += (float)($item['total_quantity'] ?? 0);
                    }

                    $order->orderItems()->create([
                        'order_id' => $order->id,
                        'product_id' => $item['product_id'],
                        'total_quantity' => round($totalQuantity, 6),
                        'balance_quantity' => $item['balance_quantity'] ?? $totalQuantity,
                        'product_details' => !empty($productDetailsArray)  ? $productDetailsArray : null,
                    ]);
                }
            }

            if (in_array($request->status, ['Won', 'Lost'])) {


                if ($skipVolumeCheck) {
                    $totalDealVolume = (float) $request->total_volume;
                }


                $totalWonVolume = OrderItem::whereHas('order.lead', function ($q) use ($lead) {
                    $q->where('lead_chain_id', $lead->lead_chain_id)
                        ->where('status', 'Won');
                })->sum('total_quantity');

                $totalLostVolume = Lead::where('lead_chain_id', $lead->lead_chain_id)
                    ->where('status', 'Lost')
                    ->sum('lost_volume');

                $handledVolume = (float) $totalWonVolume + (float) $totalLostVolume;


                $balanceVolume = $totalDealVolume - $handledVolume;

                $f_date = $request->status == 'Won'
                    ? now()->format('Y-m-d')
                    : $request->follow_up_date;
                if ($request->status == 'Lost') {
                    $f_date = $request->status == 'Lost'
                        ? now()->format('Y-m-d')
                        : $request->follow_up_date;
                }
                if ($balanceVolume > 0) {

                    Lead::create([
                        'customer_type'         => $lead->customer_type,
                        'customer_name'         => $lead->customer_name,
                        'phone'                 => $lead->phone,
                        'address'               => $lead->address,
                        'city'                  => $lead->city,
                        'location'              => $lead->location,
                        'district_id'           => $lead->district_id,
                        'assigned_route_id'     => $lead->assigned_route_id,
                        'lead_chain_id'         => $lead->lead_chain_id, // same chain
                        'type_of_visit'         => $request->type_of_visit,
                        'construction_type'     => $request->construction_type,
                        'construction_type_name' => $request->construction_type_name,
                        'stage_of_construction' => $request->stage_of_construction,
                        'lead_score'            => $request->lead_score,
                        'lead_source'           => $request->lead_source,
                        'source_name'           => $request->source_name,
                        'follow_up_date'        => $f_date,
                        'latitude' => $request->latitude,
                        'longitude' => $request->longitude,
                        'ace_code' => $request->ace_code,
                'mitr_code' => $request->mitr_code,
                        // remaining volume
                        'total_volume'          => $balanceVolume,
                        'total_quantity'        => $balanceVolume,
                        'dealer_id'             => $request->dealer_id,
                        'status'                => 'Follow Up',
                        'notification_status'   => 'pending',
                        'created_by'            => Auth::id(),
                    ]);
                }

                // ⭐ FIX 3 — If full volume handled → create fresh OPENED lead
                if ($handledVolume >= $totalDealVolume) {

                    Lead::create([
                        'customer_type'     => $lead->customer_type,
                        'customer_name'     => $lead->customer_name,
                        'phone'             => $lead->phone,
                        'address'           => $lead->address,
                        'city'              => $lead->city,
                        'location'          => $lead->location,
                        'district_id'       => $lead->district_id,
                        'assigned_route_id' => $lead->assigned_route_id,
                        'latitude' => $request->latitude,
                        'longitude' => $request->longitude,
                        'ace_code' => $request->ace_code,
                        'mitr_code' => $request->mitr_code,
                        'lead_chain_id'     => null, // new chain
                        'status'            => 'Opened',
                        'total_volume'      => 0,
                        'total_quantity'    => 0,
                        'created_by'        => Auth::id(),
                    ]);
                }
                // Send FCM notification to assigned Dealer
                try {

                    if ($orderDetails['dealer_id'] != null) {
                        $dealer = Dealer::find($orderDetails['dealer_id']);
                        $deviceToken = $dealer->fcm_token ?? null;

                        if ($deviceToken) {
                            $title = 'Prabhus Steels Sales App Notification';
                            $body = 'Lead ' . $lead->customer_name . '  has been marked as ' . $request->status;
                            $fcm->sendNotification($deviceToken, $title, $body, 'dealers');
                        }
                    }
                } catch (\Exception $e) {
                }
            }

            DB::commit();

            return response()->json([
                'success' => true,
                'statusCode' => 200,
                'message' => 'Lead updated successfully!',
                'data' => $lead,
                'order_details' => $order,
            ], 200);
        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json([
                'success' => false,
                'statusCode' => 422,
                'message' => 'Validation error',
                'errors' => $e->errors(),
            ], 422);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'statusCode' => 500,
                'message' => $e->getMessage(),
            ], 500);
        }
    }


   

    public function leadsList(Request $request)
    {
        try {
            $user = Auth::user();
            if ($user !== null) {
                $leads = Lead::with('customerType')
                    ->where('created_by', $user->id)
                    ->orderBy('customer_name', 'asc')
                    ->get();
                if ($leads->isEmpty()) {
                    return response()->json([
                        'success' => true,
                        'statusCode' => 200,
                        'message' => 'No leads found for the logged-in user.',
                        'data' => [],
                    ], 200);
                }

                $formattedLeads = $leads->map(function ($lead) {
                    return [
                        'id' => $lead->id,
                        'customer_type' => [
                            'id' => $lead->customerType->id,
                            'name' => $lead->customerType->name,
                        ],
                        'customer_name' => $lead->customer_name,
                        'phone' => $lead->phone,
                        'address' => $lead->address,
                        'instructions' => $lead->instructions,
                        'record_details' => $lead->record_details,
                        'attachments' => $lead->attachments,
                        'latitude' => $lead->latitude,
                        'longitude' => $lead->longitude,
                        'ace_code' => $lead->ace_code,
                        'mitr_code' => $lead->mitr_code,
                        'status' => $lead->status,
                        'created_by' => $lead->created_by,
                        'created_at' => $lead->created_at->format('d/M/Y h:i A'),
                    ];
                });

                return response()->json([
                    'success' => true,
                    'statusCode' => 200,
                    'message' => 'Leads retrieved successfully!',
                    'data' => $formattedLeads,
                ], 200);
            } else {
                return response()->json([
                    'success' => false,
                    'statusCode' => 401,
                    'message' => 'Unauthorized access.',
                ], 401);
            }
        } catch (Exception $e) {
            return response()->json([
                'success' => false,
                'statusCode' => 500,
                'message' => $e->getMessage(),
            ], 500);
        }
    }

    public function getleadsFilter($customer_type_id, Request $request)
    {
        try {
            $user = Auth::user();
            if ($user !== null) {
                $query = Lead::with('customerType')
                    ->where('created_by', $user->id)
                    ->where('customer_type', $customer_type_id);

                if ($request->has('search_key') && !empty($request->search_key)) {
                    $searchKey = $request->search_key;

                    $query->where(function ($q) use ($searchKey) {
                        $q->where('customer_name', 'like', '%' . $searchKey . '%')
                            ->orWhere('phone', 'like', '%' . $searchKey . '%');
                    });
                }

                $leads = $query->orderBy('customer_name', 'asc')->get();

                if ($leads->isEmpty()) {
                    return response()->json([
                        'success' => true,
                        'statusCode' => 200,
                        'message' => 'No leads found matching the filter.',
                        'data' => [],
                    ], 200);
                }

                $formattedLeads = $leads->map(function ($lead) {
                    return [
                        'id' => $lead->id,
                        'status' => $lead->status,
                        'customer_name' => $lead->customer_name,
                        'customer_type' => $lead->customerType ? [
                            'id' => $lead->customerType->id,
                            'name' => $lead->customerType->name,
                        ] : null,
                        'city' => $lead->city,
                        // 'location' => $lead->location,
                        'phone' => $lead->phone,
                        'address' => $lead->address,
                        'district' => $lead->district ? [
                            'id' => $lead->district->id,
                            'name' => $lead->district->name,
                        ] : null,
                        'latitude' => $lead->latitude,
                        'longitude' => $lead->longitude,
                        'ace_code' => $lead->ace_code,
                        'mitr_code' => $lead->mitr_code,
                        'route_name' => $lead->tripRoute ? $lead->tripRoute->route_name : null,
                        'location' => $lead->tripRoute ? $lead->tripRoute->location_name : null,
                        'created_at' => $lead->created_at->format('d/M/Y h:i A'),
                    ];
                });

                return response()->json([
                    'success' => true,
                    'statusCode' => 200,
                    'message' => 'Leads retrieved successfully!',
                    'data' => $formattedLeads,
                ], 200);
            } else {
                return response()->json([
                    'success' => false,
                    'statusCode' => 401,
                    'message' => 'Unauthorized access.',
                ], 401);
            }
        } catch (Exception $e) {
            return response()->json([
                'success' => false,
                'statusCode' => 500,
                'message' => $e->getMessage(),
            ], 500);
        }
    }
    public function updateOpenLeads($leadId, Request $request)
    {
        try {
            $validated = $request->validate([
                'type_of_visit' => 'required|string',
                'construction_type' => 'required|string',
                'construction_type_name' => 'nullable|string',
                'stage_of_construction' => 'required|string',
                'follow_up_date' => 'required|date',
                'lead_score' => 'required|string',
                'lead_source' => 'required|string',
                'source_name' => 'nullable|string',
                'total_quantity' => 'required|integer',
                'status' => 'required|string',
            ]);

            $lead = Lead::where('id', $leadId)
                ->where('created_by', Auth::id())
                ->firstOrFail();

            $lead->update([
                'type_of_visit' => $validated['type_of_visit'],
                'construction_type' => $validated['construction_type'],
                'construction_type_name' => $validated['construction_type_name'],
                'stage_of_construction' => $validated['stage_of_construction'],
                'follow_up_date' => $validated['follow_up_date'],
                'lead_score' => $validated['lead_score'],
                'lead_source' => $validated['lead_source'],
                'source_name' => $validated['source_name'],
                'total_quantity' => $validated['total_quantity'],
                'status' => $validated['status'],
            ]);


            return response()->json([
                'success' => true,
                'statusCode' => 200,
                'message' => 'Lead updated successfully!',
                'data' => $lead,
            ], 200);
        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json([
                'success' => false,
                'statusCode' => 422,
                'message' => 'Validation error',
                'errors' => $e->errors(),
            ], 422);
        } catch (Exception $e) {
            return response()->json([
                'success' => false,
                'statusCode' => 500,
                'message' => $e->getMessage(),
            ], 500);
        }
    }
    public function updateLostLeads($leadId, Request $request)
    {
        try {
            $validated = $request->validate([
                'lost_volume' => 'required|numeric',
                'lost_to_competitor' => 'required|string',
                'competitor_name' => 'nullable|string',
                'reason_for_lost' => 'required|string',
            ]);

            $lead = Lead::where('id', $leadId)
                ->where('created_by', Auth::id())
                ->firstOrFail();

            $lead->update($validated);

            return response()->json([
                'success' => true,
                'statusCode' => 200,
                'message' => 'Lead updated successfully!',
                'data' => $lead,
            ], 200);
        } catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json([
                'success' => false,
                'statusCode' => 422,
                'message' => 'Validation error',
                'errors' => $e->errors(),
            ], 422);
        } catch (Exception $e) {
            return response()->json([
                'success' => false,
                'statusCode' => 500,
                'message' => $e->getMessage(),
            ], 500);
        }
    }

    public function createInfluencerVisit(Request $request)
    {
        try {
            $validated = $request->validate([
                'influencer_name'     => 'required|string|max:255',
                'phone' => 'required|string|max:20|unique:influencer_visits,phone',
                'place'               => 'required|string|max:255',
                'influencer_type'     => 'required|string|max:255',
                'district_id'         => 'required|integer',
                'status'              => 'required|in:Opened,Follow Up,Won,Lost',             
                'latitude'            => 'required',             
                'longitude'           => 'required',             

                // Follow Up
                'visit_type'          => 'required_if:status,Follow Up|string|max:255',
                'purpose'             => 'required_if:status,Follow Up|string|max:255',
                'lead_type'           => 'required_if:status,Follow Up|string|max:255',
                'total_deal_volume'   => 'required_if:status,Follow Up|numeric',
                'follow_up_date'      => 'required_if:status,Follow Up|nullable|date',
                'follow_up_reason'    => 'required_if:status,Follow Up|nullable|string',
                'current_project'     => 'required_if:status,Follow Up|string|max:255',
                'upcoming_project'    => 'required_if:status,Follow Up|string|max:255',
                'customer_name'    => 'required_if:status,Follow Up|string|max:255',
                'site_details'    => 'required_if:status,Follow Up|string|max:255',

                // Lost
                'lost_details.lost_volume' => 'required_if:status,Lost|nullable|numeric',
                'lost_details.lost_to_competitor' => 'nullable|string',
                'lost_details.competitor_name' => 'nullable|string',
                'lost_details.reason_for_lost' => 'nullable|string',

                // Won Order
                'won_volume'                    => 'nullable|numeric',
                'order_details.order_items'     => 'nullable|array',
                'order_details.dealer_id'       => 'nullable|exists:dealers,id',
                'order_details.payment_terms_id' => 'nullable|exists:payment_terms,id',
                'order_details.total_amount'    => 'nullable|numeric',
            ]);
            $existingInfluencer = InfluencerVisit::where('phone', $request->phone)->first();

            if ($existingInfluencer) {
                return response()->json([
                    'success' => false,
                    'statusCode' => 409,
                    'message'    => 'An influencer with this phone number already exists.',
                    'data'       => $existingInfluencer
                ], 409);
            }
            DB::beginTransaction();

            // Assign creator
            $validated['created_by'] = Auth::id();
            $validated['status'] = $validated['status'] ?? 'Opened';

            /** CREATE MAIN VISIT */
            $visit = InfluencerVisit::create($validated);

            $total = $visit->total_deal_volume;
            $won = 0;
            $lost = 0;

            if ($visit->status === 'Follow Up') {
                InfluencerVisitFollowUp::create([
                    'influencer_visit_id' => $visit->id,
                    'follow_up_date'      => $request->follow_up_date,
                    'reason'              => $request->follow_up_reason,
                    'latitude'            => $request->latitude,       
                    'longitude'           => $request->longitude,
                    'notification_status' => 'pending',
                    'created_by'          => Auth::id(),
                ]);
            }

            if ($visit->status === 'Lost') {
                $lost = (float)$request->lost_details['lost_volume'];

                $visit->update([
                    'lost_volume'        => $lost,
                    'lost_to_competitor' => $request->lost_details['lost_to_competitor'],
                    'competitor_name'    => $request->lost_details['competitor_name'],
                    'reason_for_lost'    => $request->lost_details['reason_for_lost'],
                ]);
            }

            if ($visit->status === 'Won') {
                $won = (float)$request->won_volume;

                $visit->update(['won_volume' => $won]);

                if (!empty($request->order_details)) {
                    $details = $request->order_details;

                    $order = Order::create([
                        'influencer_visit_id' => $visit->id,
                        'dealer_id'           => $details['dealer_id'] ?? null,
                        'product_id' => !empty($details['order_items'][0]['product_id'])
                            ? $details['order_items'][0]['product_id']
                            : null,
                        'payment_terms_id'    => $details['payment_terms_id'] ?? null,
                        'credit_days'         => $details['credit_days'] ?? null,
                        'scheme'              => $details['scheme'] ?? null,
                        'billing_date' => !empty($details['billing_date'])
                            ? Carbon::createFromFormat('d/m/Y', $details['billing_date'])->format('Y-m-d')
                            : null,

                        'delivery_date' => !empty($details['delivery_date'])
                            ? Carbon::createFromFormat('d/m/Y', $details['delivery_date'])->format('Y-m-d')
                            : null,
                        'vehicle_category_id' => $details['vehicle_category_id'] ?? null,
                        'attachment'          => $details['attachment'] ?? null,
                        'total_amount'        => $details['total_amount'] ?? null,
                        'latitude'            => $request->latitude,       
                        'longitude'           => $request->longitude,
                        'source'              => 'influencer_won',
                        'status'              => 'Pending',
                        'created_by'          => Auth::id(),
                    ]);

                    foreach ($details['order_items'] as $item) {
                        $order->orderItems()->create($item);
                    }
                }
            }

            $balance = $total - ($won + $lost);
            // $visit->update(['balance_deal_volume' => $balance]);


            // if ($balance <= 0 || in_array($visit->status, ['Lost', 'Won'], true)) {
            //     $total_deal_volume=0;
            //     if ($visit->status === 'Lost' || $visit->status === 'Won') {
            //         $total_deal_volume = $request->total_deal_volume;
            //     }
            //     $newVisit = InfluencerVisit::create([
            //         'influencer_name'     => $visit->influencer_name,
            //         'phone'               => $visit->phone,
            //         'place'               => $visit->place,
            //         'influencer_type'     => $visit->influencer_type,
            //         'visit_type'          => $visit->visit_type,
            //         'purpose'             => $visit->purpose,
            //         'district_id'         => $visit->district_id,
            //         'lead_type'           => $visit->lead_type,
            //         'current_project'     => $visit->current_project,
            //         'upcoming_project'    => $visit->upcoming_project,
            //         // 'steel_used'          => $visit->steel_used,
            //         // 'other_steels'        => $visit->other_steels,

            //         'total_deal_volume'   => $total_deal_volume,
            //         'status'              => 'Opened',
            //         'chain_id'            => $visit->id,
            //         'created_by'          => $visit->created_by,
            //     ]);
            // }

            DB::commit();

            return response()->json([
                'success' => true,
                'statusCode' => 201,
                'message'    => 'Influencer visit created successfully.',
                'data'       => $visit
            ], 201);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'statusCode' => 500,
                'message'    => $e->getMessage(),
                'data'       => null
            ], 500);
        }
    }

    public function updateInfluencerVisit(Request $request, $visitId, FirebasePushService $fcm)
    {
        try {
            $validated = $request->validate([
                'status' => 'required|in:Opened,Follow Up,Won,Lost',

                'follow_up_date'   => 'required_if:status,Follow Up|nullable|date',
                'follow_up_reason' => 'nullable|string',

                'lost_details.lost_volume'        => 'nullable|numeric',
                'lost_details.lost_to_competitor' => 'nullable|string',
                'lost_details.competitor_name'    => 'nullable|string',
                'lost_details.reason_for_lost'    => 'nullable|string',

                'won_volume'                     => 'nullable|numeric',
                'order_details.order_items'      => 'nullable|array',
                'order_details.dealer_id'        => 'nullable|exists:dealers,id',
                'order_details.payment_terms_id' => 'nullable|exists:payment_terms,id',
                'order_details.total_amount'     => 'nullable|numeric',
                'latitude'            => 'required',             
                'longitude'           => 'required', 
                
            ]);

            $visit = InfluencerVisit::findOrFail($visitId);

            DB::beginTransaction();

            $total   = (float) ($visit->total_deal_volume ?? 0);
            $oldWon  = (float) ($visit->won_volume ?? 0);
            $oldLost = (float) ($visit->lost_volume ?? 0);

            // start with previous values, will be overwritten if new values provided
            $won  = $oldWon;
            $lost = $oldLost;

            // If Follow Up status is requested, create a follow up record (not a new visit)
            if ($request->status === 'Follow Up') {
                InfluencerVisitFollowUp::create([
                    'influencer_visit_id' => $visit->id,
                    'follow_up_date'      => $request->follow_up_date,
                    'reason'              => $request->follow_up_reason,
                    'notification_status' => 'pending',
                    'created_by'          => Auth::id(),
                ]);
            }

            // LOST handling
            if ($request->status === 'Lost') {
                $lost = (float) data_get($request, 'lost_details.lost_volume', $oldLost);

                $visit->lost_volume        = $lost;
                $visit->lost_to_competitor = data_get($request, 'lost_details.lost_to_competitor');
                $visit->competitor_name    = data_get($request, 'lost_details.competitor_name');
                $visit->reason_for_lost    = data_get($request, 'lost_details.reason_for_lost');
            }

            // WON handling + create order if provided
            if ($request->status === 'Won') {
                $won = (float) ($request->won_volume ?? $oldWon);
                $visit->won_volume = $won;

                if (!empty($request->order_details)) {
                    $details = $request->order_details;

                    $order = Order::create([
                        'influencer_visit_id' => $visit->id,
                        'dealer_id'           => $details['dealer_id'] ?? null,
                        'product_id'          => !empty($details['order_items'][0]['product_id'])
                            ? $details['order_items'][0]['product_id']
                            : null,
                        'payment_terms_id'    => $details['payment_terms_id'] ?? null,
                        'credit_days'         => $details['credit_days'] ?? null,
                        'scheme'              => $details['scheme'] ?? null,
                        'billing_date'        => !empty($details['billing_date'])
                            ? Carbon::createFromFormat('d/m/Y', $details['billing_date'])->format('Y-m-d')
                            : null,
                        'delivery_date'       => !empty($details['delivery_date'])
                            ? Carbon::createFromFormat('d/m/Y', $details['delivery_date'])->format('Y-m-d')
                            : null,
                        'total_amount'        => $details['total_amount'] ?? null,
                        'vehicle_category_id' => $details['vehicle_category_id'] ?? null,
                        'source'              => 'influencer_won',
                        'status'              => 'Pending',
                        'latitude'            => $request->latitude,       
                        'longitude'           => $request->longitude,
                        'created_by'          => Auth::id(),
                    ]);

                    foreach ($details['order_items'] as $item) {
                        $order->orderItems()->create($item);
                    }
                    // Send FCM notification to assigned Dealer
                    try {
                        if ($details['dealer_id'] != null) {
                            $dealer = Dealer::find($details['dealer_id']);
                            $deviceToken = $dealer->fcm_token ?? null;

                            if ($deviceToken) {
                                $title = 'Prabhus Steels Sales App Notification';
                                $body = 'Influencer visit won successfully ' . now()->format('d/m/Y');
                                $fcm->sendNotification($deviceToken, $title, $body, 'dealers');
                            }
                        }
                    } catch (\Exception $e) {
                    }
                }
            }

            // Calculate balance
            $balance = $total - ($won + $lost);

            // Update the base visit fields (do not try to update non-existent columns)
            $visit->status = $request->status;
            $visit->won_volume = $visit->won_volume ?? $won;
            $visit->lost_volume = $visit->lost_volume ?? $lost;
            // don't persist balance_deal_volume if the column doesn't exist; compute as needed
            $visit->save();

            // refresh model so fields like steel_used/current_project are available
            $visit->refresh();

            // Determine root chain id: use existing chain_id if present, otherwise the current visit id
            $rootChainId = $visit->chain_id ?? $visit->id;

            // Create next follow-up visit when there is remaining balance
            if (in_array($request->status, ['Won', 'Lost']) && $balance > 0) {
                InfluencerVisit::create([
                    'influencer_name'   => $visit->influencer_name,
                    'phone'             => $visit->phone,
                    'place'             => $visit->place,
                    'influencer_type'   => $visit->influencer_type,
                    'visit_type'        => $visit->visit_type,
                    'purpose'           => $visit->purpose,
                    'district_id'       => $visit->district_id,
                    'lead_type'         => $visit->lead_type,
                    'current_project'   => $visit->current_project,
                    'upcoming_project'  => $visit->upcoming_project,
                    // 'steel_used'        => $visit->steel_used,
                    // 'other_steels'      => $visit->other_steels,
                    'total_deal_volume' => $balance,
                    'latitude'            => $request->latitude,       
                    'longitude'           => $request->longitude, 
                    'status'            => 'Follow Up',
                    'chain_id'          => $rootChainId,   // <-- use root id
                    'created_by'        => $visit->created_by,
                ]);
            }

            // Create new opened visit when fully closed (if you want these to be part of chain,
            // set chain_id => $rootChainId; otherwise keep null)
            if (in_array($request->status, ['Won', 'Lost']) && $balance <= 0) {
                InfluencerVisit::create([
                    'influencer_name'   => $visit->influencer_name,
                    'phone'             => $visit->phone,
                    'place'             => $visit->place,
                    'influencer_type'   => $visit->influencer_type,
                    'visit_type'        => $visit->visit_type,
                    'purpose'           => $visit->purpose,
                    'district_id'       => $visit->district_id,
                    'lead_type'         => $visit->lead_type,
                    'current_project'   => $visit->current_project,
                    'upcoming_project'  => $visit->upcoming_project,
                    // 'steel_used'        => $visit->steel_used,
                    // 'other_steels'      => $visit->other_steels,
                    'latitude'            => $request->latitude,       
                    'longitude'           => $request->longitude,
                    'total_deal_volume' => 0,
                    'status'            => 'Opened',
                    'chain_id'          => 0,  // keep same chain if desired; set null if you want new root
                    'created_by'        => $visit->created_by,
                ]);
            }

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Influencer visit updated successfully.',
                'data'    => $visit
            ], 200);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 500);
        }
    }


public function influencerVisitListing(Request $request)
{
    try {
        $employee = Auth::user();

        if (!$employee) {
            return response()->json([
                'success' => false,
                'statusCode' => 401,
                'message' => "User not Authenticated",
            ], 401);
        }

        $visits = InfluencerVisit::select(
                'id',
                'influencer_name',
                'purpose',
                'created_at',
                'updated_at',
                'follow_up_date',
                'status'
            )
            ->where('created_by', $employee->id)
            ->get();

        $visits = $visits
            ->map(function ($visit) {

                /**
                 * 1️⃣ Activity date (created / updated based on status)
                 */
                $activityDate = in_array($visit->status, ['Follow Up', 'Won', 'Lost'])
                    ? $visit->updated_at
                    : $visit->created_at;

                /**
                 * 2️⃣ Follow-up date
		 */
		$followUpDate=null;
                    if($visit->status!="Won" && $visit->status!="Lost")
                    {
                        $followUpDate = $visit->follow_up_date
                            ? Carbon::parse($visit->follow_up_date)
                            : null;
                    }
               // $followUpDate = $visit->follow_up_date
                 //   ? Carbon::parse($visit->follow_up_date)
                   // : null;

                /**
                 * 3️⃣ Combined date for sorting (latest wins)
                 */
                $sortDate = collect([$activityDate, $followUpDate])
                    ->filter()
                    ->max();

                return [
                    'id' => $visit->id,
                    'influencer_name' => $visit->influencer_name,
                    'purpose' => $visit->purpose,

                    // ✅ RETURN BOTH DATES
                    'created_at' => optional($activityDate)->format('d/m/Y h:i A'),
                    'follow_up_date' => optional($followUpDate)->format('d/m/Y h:i A'),

                    'status' => $visit->status,

                    // internal field for sorting
                    '_sort_date' => $sortDate,
                ];
            })
            ->sortByDesc('_sort_date')
            ->values()
            ->map(function ($visit) {
                unset($visit['_sort_date']);
                return $visit;
            });

        // 🔔 Mark notifications as opened
        InfluencerVisitFollowUp::where('created_by', $employee->id)
            ->where('notification_status', 'pending')
            ->update([
                'notification_status' => 'opened'
            ]);

        return response()->json([
            'success' => true,
            'statusCode' => 200,
            'message' => 'Influencer visit list fetched successfully.',
            'data' => $visits,
        ], 200);

    } catch (\Exception $e) {
        return response()->json([
            'success' => false,
            'statusCode' => 500,
            'message' => $e->getMessage(),
        ], 500);
    }
}
    
    public function influencerOpenList()
    {
        return $this->getInfluencerVisitListByStatus(['Opened', 'Follow Up']);
    }
    public function influencerWonList(Request $request)
    {
        $productId = $request->product_id;
        return $this->getInfluencerVisitListByStatus(['Won'], $productId);
    }
    public function influencerLostList()
    {
        return $this->getInfluencerVisitListByStatus(['Lost']);
    }
private function getInfluencerVisitListByStatus(array $statuses, $productId = null)
{
	 $employee = Auth::user();

        if (!$employee) {
            return response()->json([
                'success' => false,
                'statusCode' => 401,
                'message' => "User not Authenticated",
            ], 401);
        }
    $query = InfluencerVisit::with('createdBy')
	    ->where('created_by', $employee->id)
	    ->whereIn('status', $statuses);

    if ($productId) {
        $query->whereHas('createdBy', function ($q) use ($productId) {
            $q->whereJsonContains('products', (string) $productId);
        });
    }

    $visits = $query->get();

    $data = $visits->map(function ($visit) {

        // 🔑 Decide sorting date
        if ($visit->status === 'Follow Up') {
            $sortDate = $visit->follow_up_date
                ? Carbon::parse($visit->follow_up_date)
                : $visit->updated_at;
        } else {
            $sortDate = $visit->created_at;
        }

        return [
            'id'               => $visit->id,
            'influencer_name'  => $visit->influencer_name,
            'purpose'          => $visit->purpose,
            'created_at'       => $visit->created_at
                                    ? $visit->created_at->format('d/m/Y h:i A')
                                    : null,
            'follow_up_date'   => $visit->follow_up_date
                                    ? Carbon::parse($visit->follow_up_date)->format('d/m/Y h:i A')
                                    : Carbon::parse($sortDate)->format('d/m/Y h:i A'),
            'status'           => $visit->status,

            // ⚠️ internal key only for sorting
            '_sort_date'       => $sortDate,
        ];
    });

    // 🔥 SORT BY COMBINED DATE (DESC)
    $data = $data->sortByDesc('_sort_date')->values();

    // remove internal field
    $data = $data->map(function ($item) {
        unset($item['_sort_date']);
        return $item;
    });

    return response()->json([
        'success'    => true,
        'statusCode'=> 200,
        'message'   => 'Influencer visit list fetched successfully.',
        'data'      => $data
    ]);
}
    private function getInfluencerVisitListByStatusReOld(array $statuses, $productId = null)
{
    $employee = Auth::user();

    if (!$employee) {
        return response()->json([
            'success' => false,
            'statusCode' => 401,
            'message' => "User not Authenticated",
        ], 401);
    }

    $query = InfluencerVisit::select(
            'id',
            'influencer_name',
            'purpose',
            'created_at',
            'updated_at',
            'follow_up_date',
            'status'
        )
        ->where('created_by', $employee->id)
        ->whereIn('status', $statuses);

    if ($productId) {
        $query->whereHas('order', function ($q) use ($productId) {
            $q->where('product_id', $productId);
        });
    }

    $visits = $query->get()
        ->map(function ($visit) use ($statuses) {

            /**
             * 1️⃣ Activity date (status-based)
             */
            $activityDate = in_array($visit->status, ['Follow Up', 'Won', 'Lost'])
                ? $visit->updated_at
                : $visit->created_at;

            /**
             * 2️⃣ Follow-up date
	     */
	    $followUpDate = $visit->status === 'Follow Up'
    ? ($visit->follow_up_date ? Carbon::parse($visit->follow_up_date) : $visit->updated_at)
    : null;

            /**
             * 3️⃣ Effective date for sorting
             */
            $sortDate = collect([$activityDate, $followUpDate])
                ->filter()
                ->max();

            return [
                'id' => $visit->id,
                'influencer_name' => $visit->influencer_name,
                'purpose' => $visit->purpose,

                // ✅ RETURN BOTH
                'created_at' => optional($activityDate)->format('d/m/Y h:i A'),
                'follow_up_date' => optional($followUpDate)->format('d/m/Y h:i A'),

                'status' => $visit->status,

                // internal helper
                '_sort_date' => $sortDate,
            ];
        })
        ->sortByDesc('_sort_date')
        ->values()
        ->map(function ($visit) {
            unset($visit['_sort_date']);
            return $visit;
        });

    return response()->json([
        'success' => true,
        'statusCode' => 200,
        'message' => 'Influencer visit list fetched successfully.',
        'data' => $visits,
    ], 200);
}
    private function getInfluencerVisitListByStatusOld(array $statuses, $productId = null)
    {
        $employee = Auth::user();

        if (!$employee) {
            return response()->json([
                'success' => false,
                'statusCode' => 401,
                'message' => "User not Authenticated",
            ], 401);
        }

        $query = InfluencerVisit::select(
            'id',
            'influencer_name',
            'purpose',
            'created_at',
	    'updated_at', 
	    'follow_up_date',
            'status'
        )
            ->where('created_by', $employee->id)
            ->whereIn('status', $statuses)
            ->orderBy('created_at', 'desc');

        if ($productId) {
            $query->whereHas('order', function ($q) use ($productId) {
                $q->where('product_id', $productId);
            });
        }
        $visits = $query->get()->map(function ($visit) {
            return [
                'id' => $visit->id,
                'influencer_name' => $visit->influencer_name,
                'purpose' => $visit->purpose,
                //        'created_at' => $visit->updated_at?->format('d/m/Y h:i A'),
                'created_at' => ($visit->status === 'Follow Up' || $visit->status === 'Won' || $visit->status === 'Lost')
                    ? optional($visit->updated_at)->format('d/m/Y h:i A')
                    : optional($visit->created_at)->format('d/m/Y h:i A'),
		    'follow_up_date' => optional($visit->created_at)->format('d/m/Y h:i A') ?? null,
		                    'status' => $visit->status,
            ];
        });

        return response()->json([
            'success' => true,
            'statusCode' => 200,
            'message' => 'Influencer visit list fetched successfully.',
            'data' => $visits,
        ], 200);
    }



    public function influencerVisitDetails($visitId)
    {
        try {
            $visit = InfluencerVisit::with([
                'district',
                'followUps' => function ($query) {
                    $query->orderBy('follow_up_date', 'asc');
                },
                'order.orderItems.product',
                'order.paymentTerm',
                'order.dealer',
            ])->findOrFail($visitId);

            $data = [
                'id' => $visit->id,
                'influencer_name' => $visit->influencer_name,
                'phone' => $visit->phone,
                'place' => $visit->place,
                'influencer_type' => $visit->influencer_type,
                'visit_type' => $visit->visit_type,
                'purpose' => $visit->purpose,
                'lead_type' => $visit->lead_type,
                'district' => $visit->district ? [
                    'id' => $visit->district->id,
                    'name' => $visit->district->name,
                ] : null,
                'status' => $visit->status,
                'created_at' => optional($visit->created_at)->format('d/m/Y'),
            ];

            // ---------------------------------------------------------
            // COMMON FIELDS FOR ALL STATUSES
            // ---------------------------------------------------------
            $data['follow_up_date'] = optional($visit->follow_up_date)->format('d/m/Y');
            $data['current_project'] = $visit->current_project;
            $data['upcoming_project'] = $visit->upcoming_project;
            // $data['steel_used'] = $visit->steel_used;
            // $data['other_steels'] = $visit->other_steels;


            if ($visit->chain_id) {
                $parentVolume = InfluencerVisit::where('id', $visit->chain_id)
                    ->value('total_deal_volume');

                $data['total_deal_volume'] =  ($parentVolume ?? 0);
            } else {
                $data['total_deal_volume'] =  $visit->total_deal_volume;
            }

            $leadParentId = $visit->chain_id ?? $visit->id;

            $leadVisits = InfluencerVisit::where(function ($q) use ($leadParentId) {
                $q->where('id', $leadParentId)
                    ->orWhere('chain_id', $leadParentId);
            })->get();

            $data['won_volume'] = (float) $leadVisits->sum('won_volume');
            $data['lost_volume'] = (float) $leadVisits->sum('lost_volume');
            $data['follow_ups'] = $visit->followUps->map(function ($followUp) {
                return [
                    'id' => $followUp->id,
                    'follow_up_date' => optional($followUp->follow_up_date)->format('d/m/Y'),
                    'follow_up_reason' => $followUp->reason,
                ];
            })->values();


            if ($visit->status === 'Lost') {
                $data['lost_volume'] = (float) $visit->lost_volume;
                $data['lost_to_competitor'] = $visit->lost_to_competitor;
                $data['competitor_name'] = $visit->competitor_name;
                $data['reason_for_lost'] = $visit->reason_for_lost;
            }

            if ($visit->status === 'Won' && $visit->order) {
                $order = $visit->order;
                $orderItems = $order->orderItems->map(function ($item) {

                    $productDetails = collect($item->product_details)->map(function ($detail) {
                        $productType = ProductType::find($detail['product_type_id']);

                        return [
                            'product_type_id' => $detail['product_type_id'] ?? null,
                            'type_name' => $productType->type_name ?? null,
                            'quantity' => isset($detail['quantity']) ? (float)$detail['quantity'] : null,
                            'pieces' => isset($detail['pieces']) ? (int)$detail['pieces'] : null,
                            'tonnage' => isset($detail['tonnage']) ? (float)$detail['tonnage'] : null,
                            'rate' => $detail['rate'] ?? null,
                            'quantity_type' => $detail['quantity_type'] ?? null,
                        ];
                    });

                    $totalPieces = $productDetails->sum('pieces');

                    $totalTonnage = $productDetails->sum(function ($detail) {
                        return ($detail['pieces'] ?? 0) * ($detail['tonnage'] ?? 0);
                    });

                    return [
                        'product_id' => $item->product_id,
                        'product_name' => $item->product->product_name ?? null,
                        'product_code' => $item->product->product_code ?? null,
                        'total_quantity' => (float)($item->total_quantity ?? 0),
                        'total_pieces' => $totalPieces > 0 ? $totalPieces : null,
                        'total_ton' => $totalTonnage > 0 ? $totalTonnage : null,
                        'product_details' => $productDetails,
                    ];
                });

                $data['order'] = [
                    'id' => $order->id,
                    'total_amount' => $order->total_amount,
                    'status' => $order->status,
                    'credit_days' => $order->credit_days,
                    'dealer' => $order->dealer ? [
                        'id' => $order->dealer->id,
                        'name' => $order->dealer->dealer_name,
                        'code' => $order->dealer->dealer_code,
                    ] : null,
                    'payment_terms' => $order->paymentTerm ? [
                        'id' => $order->paymentTerm->id,
                        'name' => $order->paymentTerm->name,
                    ] : null,
                    'attachment' => $order->attachment ?: null,
                    'order_items' => $orderItems
                ];
            }


            return response()->json([
                'success' => true,
                'statusCode' => 200,
                'message' => 'Influencer visit details fetched successfully.',
                'data' => $data,
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'statusCode' => 500,
                'message' => $e->getMessage(),
            ], 500);
        }
    }


    public function LeadOpenList(Request $request)
    {
        try {
            $user = Auth::user();
            if (!$user) {
                return response()->json([
                    'success' => false,
                    'statusCode' => 401,
                    'message' => 'Unauthorized access.',
                ], 401);
            }

            $leads = Lead::with('customerType')
                ->where('created_by', $user->id)
                ->where(function ($q) {
                    $q->where('status', '!=', 'Follow Up')
                        ->orWhere(function ($q2) {
                            $q2->where('status', 'Follow Up')
                                ->whereNotNull('follow_up_date');
                        });
                })->whereNotIn('status', ['Won', 'Lost'])
                ->orderBy('created_at', 'desc')
                ->get();

            if ($leads->isEmpty()) {
                return response()->json([
                    'success' => true,
                    'statusCode' => 200,
                    'message' => 'No leads found.',
                    'data' => [],
                ], 200);
            }
		$formattedLeads = $leads->map(function ($lead) {

                $status = $lead->status === 'Follow Up' ? 'Follow Up' : 'Opened';

                $lead_id = $lead->id;

                if ($lead->status === 'Won' || $lead->status === 'Lost') {
                    $lead_last = Lead::where('phone', $lead->phone)
                        ->where('status', 'Follow Up')
                        ->orderBy('created_at', 'desc')
                        ->first();

                    if ($lead_last) {
                        $lead_id = $lead_last->id;
                    }
                }

                // determine actual date
                $date = $lead->status === 'Follow Up'
                    ? $lead->follow_up_date
                    : (($lead->status === 'Won' || $lead->status === 'Lost')
                        ? $lead->updated_at
                        : $lead->created_at);

                return [
                    'id' => $lead_id,
                    'customer_type' => [
                        'id' => $lead->customerType->id ?? null,
                        'name' => $lead->customerType->name ?? null,
                    ],
                    'view_lead_id' => $lead->id,
                    'customer_name' => $lead->customer_name,
                    'phone' => $lead->phone,
                    'address' => $lead->address,
                    'status' => $status,
                    'latitude' => $lead->latitude,
                        'longitude' => $lead->longitude,
                        'ace_code' => $lead->ace_code,
                        'mitr_code' => $lead->mitr_code,
                    'location' => $lead->location,
                    'lead_source' => $lead->lead_source,
                    'lead_score' => $lead->lead_score,
                    'created_by' => $lead->created_by,
                    'sort_date' => $date, // for sorting
                    'created_at' => optional(Carbon::parse($date))->format('d/m/Y h:i A'),
                ];
            })
            ->sortByDesc('sort_date')   // SORT HERE
            ->values()
            ->map(function ($lead) {
                unset($lead['sort_date']); // remove helper field
                return $lead;
	    });

            
            return response()->json([
                'success' => true,
                'statusCode' => 200,
                'message' => 'Opened and Follow Up leads retrieved successfully!',
                'data' => $formattedLeads,
            ], 200);
        } catch (Exception $e) {
            return response()->json([
                'success' => false,
                'statusCode' => 500,
                'message' => $e->getMessage(),
            ], 500);
        }
    }

    public function LeadWonList(Request $request)
    {
        $productId = $request->product_id;
        return $this->getLeadsByStatus('Won', 'Won leads retrieved successfully!', $productId);
    }

    public function LeadFollowupList(Request $request)
    {
        return $this->getLeadsByStatus('Follow Up', 'Follow up leads retrieved successfully!');
    }

    public function LeadLostList(Request $request)
    {
        return $this->getLeadsByStatus('Lost', 'Lost leads retrieved successfully!');
    }
    private function getLeadsByStatus($status, $message, $productId = null)
    {
        try {
            $user = Auth::user();
            if (!$user) {
                return response()->json([
                    'success' => false,
                    'statusCode' => 401,
                    'message' => 'Unauthorized access.',
                ], 401);
            }

            $query = Lead::with(['customerType'])
                ->where('created_by', $user->id)
                ->where('status', $status);

            if ($productId) {
                $query->whereHas('orders', function ($q) use ($productId) {
                    $q->where('product_id', $productId);
                });
            }

            $leads = $query->orderBy('updated_at', 'desc')->get();
            if ($status === 'Follow Up') {
                LeadFollowUp::where('created_by', $user->id)
                    ->where('notification_status', 'pending')
                    // ->whereIn('lead_id', $leads->pluck('id'))
                    ->update([
                        'notification_status' => 'opened'
                    ]);
            }
            return $this->formatLeadsResponse($leads, $message,$status); //push
        } catch (Exception $e) {
            return $this->handleException($e);
        }
    }

    private function formatLeadsResponse($leads, $message,$status) //push
    {
        if ($leads->isEmpty()) {
            return response()->json([
                'success' => true,
                'statusCode' => 200,
                'message' => 'No leads found.',
                'data' => [],
            ], 200);
        }

        $formattedLeads = $leads->map(function ($lead) use ($status) {

            
            $lead_id = $lead->id;
            $orderstatus="";   
            if ($status === 'Won' || $status === 'Lost') {
	
                $lead_last = Lead::where('phone', $lead->phone)
                    ->where('status', 'Follow Up')
                    ->orderBy('created_at', 'desc')
                    ->first();

                if ($lead_last) {
                    $lead_id = $lead_last->id;
		}
		if($status === 'Won'){
                    $orderstatus = Order::where('lead_id', $lead->id)->value('status') ?? "Pending";
                }
            }

            
            return [
                'id' => $lead_id,
                'customer_type' => [
                    'id' => $lead->customerType->id ?? null,
                    'name' => $lead->customerType->name ?? null,
		],
		'order_status' => $orderstatus,
                'view_lead_id' => $lead->id,
                'customer_name' => $lead->customer_name,
                'phone' => $lead->phone,
                'address' => $lead->address,
                'status' => $lead->status,
                'lead_source' => $lead->lead_source,
                'lead_score' => $lead->lead_score,
                'location' => $lead->location,
                'created_by' => $lead->created_by,
                'latitude' => $lead->latitude,
                'longitude' => $lead->longitude,
                'ace_code' => $lead->ace_code,
                'mitr_code' => $lead->mitr_code,
                'created_at' => ($lead->status === 'Follow Up' || $lead->status === 'Won' || $lead->status === 'Lost')
                    ? optional($lead->updated_at)->format('d/m/Y h:i A')
                    : optional($lead->created_at)->format('d/m/Y h:i A')
                //  'created_at' => $lead->created_at->format('d/M/Y h:i A'),
            ];
        });

        return response()->json([
            'success' => true,
            'statusCode' => 200,
            'message' => $message,
            'data' => $formattedLeads,
        ], 200);
    }

    private function handleException($e)
    {
        return response()->json([
            'success' => false,
            'statusCode' => 500,
            'message' => $e->getMessage(),
        ], 500);
    }
public function influencerSearch(Request $request)
{
    $employee = Auth::user();
    if (!$employee) {
        return response()->json([
            'success' => false,
            'statusCode' => 401,
            'message' => "User not Authenticated",
        ], 401);
    }

    // ✅ UPDATED (trim + normalize inputs)
    $search    = trim($request->search);            // ✅ UPDATED
    $status    = trim($request->status);            // ✅ UPDATED
    $productId = $request->product_id;

    $query = InfluencerVisit::select(
            'id',
            'influencer_name',
            'purpose',
            'created_at',
            'updated_at',
            'follow_up_date',
            'status'
        )
        ->where('created_by', $employee->id);

    /**
     * ✅ UPDATED: FIXED STATUS FILTER (case-insensitive + strict match)
     */
 //   if (!empty($status)) { // ✅ UPDATED
 //       $query->whereRaw('LOWER(status) = ?', [strtolower($status)]); // ✅ UPDATED
//    }
 if ($status === 'Opened') {
            $query->whereIn('status', ['Opened', 'Follow Up']);
        } elseif ($status) {
            $query->where('status', $status);
        }
    /**
     * Search filter
     */
    if (!empty($search)) { // ✅ UPDATED
        $query->where(function ($q) use ($search) {
            $q->where('influencer_name', 'LIKE', "%{$search}%");
            // ->orWhere('purpose', 'LIKE', "%{$search}%");
        });
    }

    /**
     * Product filter (only for Won)
     */
    if (strtolower($status) === 'won' && $productId) { // ✅ UPDATED
        $query->whereHas('order', function ($q) use ($productId) {
            $q->where('product_id', $productId);
        });
    }

    /**
     * Fetch → combine dates → sort
     */
    $visits = $query->get()
        ->map(function ($visit) use ($status) {

            // 1️⃣ Activity date
            $activityDate = in_array($visit->status, ['Follow Up', 'Won', 'Lost'])
                ? $visit->updated_at
                : $visit->created_at;

            $followUpDate = null;

            // ✅ UPDATED (case-insensitive check)
            if (!in_array(strtolower($status), ['won', 'lost'])) { // ✅ UPDATED
                $followUpDate = $visit->follow_up_date
                    ? Carbon::parse($visit->follow_up_date)
                    : null;
            }

            // 3️⃣ Effective date (latest)
            $sortDate = collect([$activityDate, $followUpDate])
                ->filter()
                ->max();

            return [
                'id' => $visit->id,
                'influencer_name' => $visit->influencer_name,
                'purpose' => $visit->purpose,

                'created_at' => optional($activityDate)->format('d/m/Y h:i A'),
                'follow_up_date' => optional($followUpDate)->format('d/m/Y h:i A'),

                'status' => $visit->status,

                '_sort_date' => $sortDate,
            ];
        })
        ->sortByDesc('_sort_date')
        ->values()
        ->map(function ($visit) {
            unset($visit['_sort_date']);
            return $visit;
        });

    return response()->json([
        'success' => true,
        'statusCode' => 200,
        'message' => 'Influencer visit search results fetched successfully.',
        'data' => $visits,
    ], 200);
}
    public function influencerSearcholdd(Request $request)
    {
        $employee = Auth::user();
        if (!$employee) {
            return response()->json([
                'success' => false,
                'statusCode' => 401,
                'message' => "User not Authenticated",
            ], 401);
        }

        $search    = $request->search;
        $status    = $request->status;
        $productId = $request->product_id;

        $query = InfluencerVisit::select(
                'id',
                'influencer_name',
                'purpose',
                'created_at',
                'updated_at',
                'follow_up_date',
                'status'
            )
            ->where('created_by', $employee->id);

        /**
         * Status filters
         */
        if ($status === 'Opened') {
            $query->whereIn('status', ['Opened', 'Follow Up']);
        } elseif ($status) {
            $query->where('status', $status);
        }

        /**
         * Search filter
         */
        if ($search) {
            $query->where(function ($q) use ($search) {
                $q->where('influencer_name', 'LIKE', "%{$search}%");
      //          ->orWhere('purpose', 'LIKE', "%{$search}%");
            });
        }

        /**
         * Product filter (only for Won)
         */
        if ($status === 'Won' && $productId) {
            $query->whereHas('order', function ($q) use ($productId) {
                $q->where('product_id', $productId);
            });
        }

        /**
         * Fetch → combine dates → sort
         */
        $visits = $query->get()
            ->map(function ($visit) use ($status) {

                // 1️⃣ Activity date
                $activityDate = in_array($visit->status, ['Follow Up', 'Won', 'Lost'])
                    ? $visit->updated_at
                    : $visit->created_at;
 $followUpDate=null;
                if($status!="Won" && $status!="Lost")
                {
                // 2️⃣ Follow-up date
                $followUpDate = $visit->follow_up_date
                    ? Carbon::parse($visit->follow_up_date)
                    : null;
		}
                // 3️⃣ Effective date (latest)
                $sortDate = collect([$activityDate, $followUpDate])
                    ->filter()
                    ->max();

                return [
                    'id' => $visit->id,
                    'influencer_name' => $visit->influencer_name,
                    'purpose' => $visit->purpose,

                    // ✅ return both fields
                    'created_at' => optional($activityDate)->format('d/m/Y h:i A'),
                    'follow_up_date' => optional($followUpDate)->format('d/m/Y h:i A'),

                    'status' => $visit->status,

                    '_sort_date' => $sortDate,
                ];
            })
            ->sortByDesc('_sort_date')
            ->values()
            ->map(function ($visit) {
                unset($visit['_sort_date']);
                return $visit;
            });

        return response()->json([
            'success' => true,
            'statusCode' => 200,
            'message' => 'Influencer visit search results fetched successfully.',
            'data' => $visits,
        ], 200);
    }
    public function influencerSearchOld(Request $request)
    {
        $employee = Auth::user();
        if (!$employee) {
            return response()->json([
                'success' => false,
                'statusCode' => 401,
                'message' => "User not Authenticated",
            ], 401);
        }

        $search = $request->search;
        $status = $request->status;
        $productId = $request->product_id;

        $query = InfluencerVisit::select('id', 'influencer_name', 'purpose', 'created_at', 'updated_at', 'follow_up_date', 'status')
            ->where('created_by', $employee->id);


        if ($status === 'Opened') {
            $query->whereIn('status', ['Opened', 'Follow Up']);
        } else {
            if ($status) {
                $query->where('status', $status);
            }
        }

        if ($search) {
            $query->where(function ($q) use ($search) {
                $q->where('influencer_name', 'LIKE', "%$search%")
                    ->orWhere('purpose', 'LIKE', "%$search%");
            });
        }

        if ($status === 'Won') {
            $query->whereHas('order', function ($q) use ($productId) {
                if ($productId) {
                    $q->where('product_id', $productId);
                }
            });
        }

        $visits = $query->orderBy('created_at', 'desc')->get()->map(function ($visit) {
            return [
                'id' => $visit->id,
                'influencer_name' => $visit->influencer_name,
                'purpose' => $visit->purpose,
                //                'created_at' => $visit->created_at?->format('d/m/Y h:i A'),
                'created_at' => ($visit->status === 'Follow Up' || $visit->status === 'Won' || $visit->status === 'Lost')
                    ? optional($visit->updated_at)->format('d/m/Y h:i A')
                    : optional($visit->created_at)->format('d/m/Y h:i A'),
                'follow_up_date' => $visit->follow_up_date ? date('d/m/Y', strtotime($visit->follow_up_date)) : null,
                'status' => $visit->status,
            ];
        });

        return response()->json([
            'success' => true,
            'statusCode' => 200,
            'message' => 'Influencer visit search results fetched successfully.',
            'data' => $visits,
        ], 200);
    }
    public function saleleads(){
        $employees = Employee::all();

        $customerTypes = \App\Models\CustomerType::orderBy('name')->get();

        $districts = \App\Models\District::orderBy('name')->get();

        return view('sales.leads.index', compact(
            'employees',
            'customerTypes',
            'districts'
        ));
        
    }
    public function leadList(Request $request){
            $query = Lead::with([
            'customerType',
            'district',
            'tripRoute',
            'createdBy','orders'
        ]);

        if ($request->filled('from_date') && $request->filled('to_date')) {

            $query->whereBetween('created_at', [
                $request->from_date . ' 00:00:00',
                $request->to_date . ' 23:59:59'
            ]);

        } elseif ($request->filled('from_date')) {

            $query->whereDate('created_at', '>=', $request->from_date);

        } elseif ($request->filled('to_date')) {

            $query->whereDate('created_at', '<=', $request->to_date);

        }
        if ($request->filled('district')) {
            $query->where(
                'district_id',
                $request->district
            );
        }

        if ($request->filled('customer_type')) {
            $query->where(
                'customer_type',
                $request->customer_type
            );
        }

        if ($request->filled('employee_id')) {
            $query->where(
                'created_by',
                $request->employee_id
            );
        }

        if ($request->filled('status')) {

            $query->where(
                'status',
                $request->status
            );
        }

        return DataTables::of($query)

            ->addIndexColumn()


            ->addColumn('date_time', function ($lead) {

            
                $date = $lead->created_at;
                $date1 = in_array($lead->status, [
                    'Follow Up',
                    'Won',
                    'Lost'
                ])
                    ? $lead->updated_at
                    : $lead->created_at;

                return $date
                    ? $date->format('d/m/Y - h:i A')
                    : '-';

            })


            ->addColumn('customer_type_name', function ($lead) {

                return $lead->customerType->name ?? '-';

            })


            ->addColumn('customer_name_display', function ($lead) {

                return $lead->customer_name ?? '-';

            })

            ->addColumn('location_display', function ($lead) {

                return $lead->location ?? '-';

            })

            ->addColumn('district_name', function ($lead) {

                return $lead->district->name ?? '-';

            })

            ->addColumn('status_display', function ($lead) {

                $status = $lead->status;

                $class = match ($status) {

                    'Follow Up' => 'follow-up',

                    'Won' => 'won',

                    'Lost' => 'lost',

                    'Opened' => 'open',

                    'Open' => 'open',

                    default => 'open',

                };

                return '<span class="lead-status ' . $class . '">'
                        . e($status)
                        . '</span>';

            })

            ->addColumn('approval_status', function ($lead) {

                // If lead is not Won
                if ($lead->status !== 'Won') {
                    return '<span class="approval-status na">NA</span>';
                }

                // Lead is Won, check order status
                $order = $lead->orders->sortByDesc('created_at')->first();

                // No order found
                if (!$order) {
                    return '<span class="approval-status na">NA</span>';
                }

                $orderStatus = $order->status;

                if (in_array($orderStatus, [
                    'Pending',
                    'Accepted'
                ])) {

                    return '<span class="approval-status pending">
                                Pending
                            </span>';
                }

                if (in_array($orderStatus, [
                    'Rejected',
                    'Accounts Rejected'
                ])) {

                    return '<span class="approval-status rejected">
                                Rejected
                            </span>';
                }

                if (in_array($orderStatus, [
                    'Dispatched',
                    'In Transit',
                    'Delivered',
                    'Accounts Approved'
                ])) {

                    return '<span class="approval-status approved">
                                Approved
                            </span>';
                }

                return '<span class="approval-status na">NA</span>';

            })
            ->addColumn('action', function ($lead) {

                return '
                    <button type="button"
                            class="btn btn-sm btn-link p-0 viewLead"
                            data-id="' . $lead->id . '"
                            title="View Lead">

                        <i class="fa fa-eye"></i>

                    </button>
                ';

            })


            ->rawColumns([
                'status_display',
                'approval_status',
                'action'
            ])

            ->make(true);

    }
    public function viewLead($id)
    {
        $lead = Lead::with([
            'customerType',
            'district',
            'createdBy',
            'followUps','assignRoute', 'orders.dealer','orders.paymentTerm','orders.customerType','orders.orderItems'
        ])->findOrFail($id);

        return response()->json($lead);
    }
    public function exportLeads(Request $request)
    {
        return Excel::download(
            new AllLeadExport($request),
            'AllLeadExport.xlsx'
        );
    }
}

