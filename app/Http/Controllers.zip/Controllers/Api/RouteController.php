<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\AssignRoute;
use App\Models\Dealer;
use App\Models\TripRoute;
use App\Models\OutstandingPaymentCommitment;
use App\Models\District;
use App\Models\EmployeeType;
use App\Models\Employee;
use App\Models\Activity;
use App\Models\CustomerType;
use App\Models\Attendance;
use App\Models\DealerTripActivity;
use App\Models\RescheduledRoute;
use App\Models\Lead;
use App\Models\InfluencerVisit;
use App\Models\DealerVisit;
use App\Models\Order;
use App\Models\DealerRouteAssignment;
use Carbon\Carbon;
use App\Helpers\ProductHelper;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Yajra\DataTables\Facades\DataTables;
use Exception;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use App\Http\Controllers\Api\AuthController;

class RouteController extends Controller
{
    public function getTodaysTrip(Request $request)
    {
        try {
            $employeeId = Auth::id(); 
            $todayDate = now()->toDateString();

            $trip = AssignRoute::with(['tripRoute', 'dealers'])
                ->where('employee_id', $employeeId)
                ->whereDate('assign_date', $todayDate)
                ->first();
            if (!$trip) {
                return response()->json([
                    'success' => true,
                    'statusCode' => 200,
                    'message' => 'No trip assigned for today.',
                    'data' => null,
                ], 200);
            }
    
            $tripData = [
                'employee_id' => $trip->employee_id,
                'trip_route_id' => $trip->trip_route_id,
                'route_name' => $trip->tripRoute->route_name ?? null,
                'assign_date' => $trip->assign_date,
                'location_name' => $trip->tripRoute->location_name ?? null,
                'status' => $trip->status,
            ];
    
            return response()->json([
                'success' => true,
                'statusCode' => 200,
                'message' => "Today's routes retrieved successfully.",
                'data' => $tripData, 
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'statusCode' => 500,
                'message' => $e->getMessage(),
            ], 500);
        }
    }
    public function viewTripDetails(Request $request, $dealerId)
    {
        try {
            $employeeId = Auth::id();

            $tripDetails = DealerTripActivity::with(['assignRoute', 'dealer'])
                ->where('dealer_id', $dealerId)
                ->whereHas('assignRoute', function($query) use ($employeeId) {
                    $query->where('employee_id', $employeeId);
                })
                ->get();

            if ($tripDetails->isEmpty()) {
                return response()->json([
                    'success' => false,
                    'statusCode' => 404,
                    'message' => 'No trip details found for the provided dealer and authenticated employee.',
                ], 404);
            }

            return response()->json([
                'success' => true,
                'statusCode' => 200,
                'message' => 'Trip details retrieved successfully.',
                'data' => $tripDetails,
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'statusCode' => 500,
                'message' => 'Failed to retrieve trip details. Please try again later.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function updateDealerTripActivity(Request $request, $dealerId)
    {
        try {
            $request->validate([
                'assign_route_id' => 'required|exists:assign_route,id',
                'record_details' => 'required|string',
                'attachments' => 'nullable|array',
                'activity_status' => 'required|in:Pending,Completed', 
            ]);

            $dealerTripActivity = DealerTripActivity::firstOrNew([
                'assign_route_id' => $request->assign_route_id,
                'dealer_id' => $dealerId,
            ]);

            $dealerTripActivity->record_details = $request->record_details;
            $dealerTripActivity->activity_status = $request->activity_status;

            if ($request->hasFile('attachments')) {
                $attachments = [];
                foreach ($request->file('attachments') as $file) {
                    $filePath = $file->store('Trip', 'public');
                    $attachments[] = $filePath;  
                }
                $dealerTripActivity->attachments = json_encode($attachments); 
            }

            if ($request->activity_status === 'Completed') {
                $dealerTripActivity->completed_date = now();
            }


            $dealerTripActivity->save();

            return response()->json([
                'success' => true,
                'statusCode' => 200,
                'message' => 'Dealer trip activity updated successfully.',
                'data' => $dealerTripActivity,
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'statusCode' => 500,
                'message' => 'Failed to update dealer trip activity. Please try again later.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function addDealerToRoute(Request $request, $tripRouteId)
    {
        try {
            $request->validate([
                'dealer_code' => 'required|string|max:10|unique:dealers,dealer_code',
                'dealer_name' => 'required|string|max:255',
                'phone' => 'required|string|max:15',
                'email' => 'required|email|max:255',
                'address' => 'required|string|max:500',
                'user_zone' => 'required|string|max:100',
                'pincode' => 'required|string|max:6',
                'state' => 'required|string|max:100',
                'district' => 'required|string|max:100',
                'taluk' => 'required|string|max:100',
            ]);

            $dealer = Dealer::create([
                'dealer_code' => $request->dealer_code,
                'dealer_name' => $request->dealer_name,
                'phone' => $request->phone,
                'email' => $request->email,
                'address' => $request->address,
                'user_zone' => $request->user_zone,
                'pincode' => $request->pincode,
                'state' => $request->state,
                'district' => $request->district,
                'taluk' => $request->taluk,
                'trip_route_id' => $tripRouteId, 
            ]);

            return response()->json([
                'success' => true,
                'statusCode' => 200,
                'message' => 'Dealer added successfully to the route.',
                'data' => $dealer,
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'statusCode' => 500,
                'message' => $e->getMessage(),
            ], 500);
        }
    }

    public function todaysRouteSchedule()
    {
        try {
            $employeeId = Auth::id();
            $today = Carbon::now();
            $weekStart = $today->copy()->startOfWeek(Carbon::MONDAY);
            $weekEnd = $today->copy()->endOfWeek(Carbon::SUNDAY);
            $todayName = $today->format('l');

            $routeMapping = [
                'Monday' => 'R1',
                'Tuesday' => 'R2',
                'Wednesday' => 'R3',
                'Thursday' => 'R4',
                'Friday' => 'R5',
                'Saturday' => 'R6',
            ];

            $scheduledCustomers = collect();
            $locations = [];
            $assignedRouteId = null;
            $routeName = $routeMapping[$todayName] ?? null;

            $rescheduledRoute = RescheduledRoute::where('employee_id', $employeeId)
                ->where('day', $todayName)
                ->whereBetween('assign_date', [$weekStart->format('Y-m-d'), $weekEnd->format('Y-m-d')])
                ->first();

            if ($rescheduledRoute) {
                $routeName = $rescheduledRoute->route_name;
                $assignedRouteId = $rescheduledRoute->assigned_route_id;
                $locations = json_decode($rescheduledRoute->locations, true);

               // $scheduledCustomers = collect(json_decode($rescheduledRoute->customers ?? '[]', true) ?? [])->map(function ($customer) {
                 //   return collect($customer)->merge(['scheduled' => true]);
		// });
		$scheduledCustomers = collect(json_decode($rescheduledRoute->customers ?? '[]', true));

            } else {
                $trip = AssignRoute::where('employee_id', $employeeId)
                    ->where('route_name', $routeName)
                    ->first();

                if (!$trip) {
                    return response()->json([
                        'success' => false,
                        'statusCode' => 404,
                        'message' => 'No route assigned for today.',
                    ], 404);
                }

                $locations = explode(', ', $trip->locations);
                $assignedRouteId = $trip->id;

                $dealers = Dealer::join('dealer_route_assignments', 'dealer_route_assignments.dealer_id', '=', 'dealers.id')
                    ->where('dealer_route_assignments.assign_route_id', $assignedRouteId)
                    ->select('dealers.id', 'dealers.dealer_name as customer_name', 'dealers.location')
                    ->get()
                    ->map(function ($dealer) {
                        return array_merge($dealer->toArray(), [
                            'customer_type' => 'Dealer',
                            'scheduled' => false
                        ]);
                    });

             
                $leads = Lead::join('customer_types', 'leads.customer_type', '=', 'customer_types.id')
                    ->where('leads.assigned_route_id', $assignedRouteId)
                    ->where(function ($query) {
                        $query->whereIn('leads.customer_type', [1, 2])
                            ->orWhere(function ($q) {
                                $q->where('leads.customer_type', 4)->where('leads.status', 'Follow Up');
                            });
                    })
                    ->get([
                        'leads.id',
                        'leads.customer_name',
                        'leads.location',
                        'customer_types.name as customer_type'
                    ])
                    ->map(function ($lead) {
                        return array_merge($lead->toArray(), ['scheduled' => false]);
                    });

                $scheduledCustomers = collect($dealers)->merge($leads);
            }

            return response()->json([
                'success' => true,
                'statusCode' => 200,
                'message' => "Today's route schedule fetched successfully.",
                'data' => [
                    'day' => $todayName,
                    'route_name' => $routeName,
                    'locations' => $locations,
                    'customers' => $scheduledCustomers->values(),
                ]
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'statusCode' => 500,
                'message' => 'Error fetching today\'s route schedule.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function currentWeekRoutes()
    {
        try {
            $employeeId = Auth::id();
            $today = Carbon::now();
            $weekStart = $today->copy()->startOfWeek(Carbon::MONDAY);
            $weekEnd = $today->copy()->endOfWeek(Carbon::SUNDAY);

            $routeMapping = [
                'Monday' => 'R1',
                'Tuesday' => 'R2',
                'Wednesday' => 'R3',
                'Thursday' => 'R4',
                'Friday' => 'R5',
                'Saturday' => 'R6',
            ];

            $weeklyRoutes = [];

            foreach ($routeMapping as $day => $defaultRouteName) {
                $customers = collect();
                $locations = [];
                $routeName = $defaultRouteName;
                $assignedRouteId = null;

                $rescheduledRoute = RescheduledRoute::where('employee_id', $employeeId)
                    ->where('day', $day)
                    ->whereBetween('assign_date', [$weekStart->format('Y-m-d'), $weekEnd->format('Y-m-d')])
                    ->first();

                if ($rescheduledRoute) {
                    $routeName = $rescheduledRoute->route_name;
                    $assignedRouteId = $rescheduledRoute->assigned_route_id;
                    $locations = json_decode($rescheduledRoute->locations, true) ?? [];
                if($rescheduledRoute->notification_status=='pending'){
                            $rescheduledRoute->update(['notification_status'=>'opened']);
                    }
                    $rescheduledCustomers = collect(
                        is_string($rescheduledRoute->customers)
                            ? json_decode($rescheduledRoute->customers, true)
                            : (is_array($rescheduledRoute->customers) ? $rescheduledRoute->customers : [])
                    )->map(function ($customer) {
                        return (array) $customer + ['scheduled' => true];
                    });
                } else {
                    $trip = AssignRoute::where('employee_id', $employeeId)
                        ->where('route_name', $routeName)
                        ->first();

                    if (!$trip) {
                        continue;
                    }
                    if($trip->notification_status=='pending'){
                        $trip->update(['notification_status'=>'opened']);
                    }
                    $locations = explode(', ', $trip->locations);
                    $assignedRouteId = $trip->id;
                    $rescheduledCustomers = collect([]);
                }

                $dealers = Dealer::join('dealer_route_assignments', 'dealer_route_assignments.dealer_id', '=', 'dealers.id')
                    ->where('dealer_route_assignments.assign_route_id', $assignedRouteId)
                    ->select('dealers.id', 'dealers.dealer_name as customer_name', 'dealers.location')
                    ->get()
                    ->map(function ($dealer) {
                        return array_merge($dealer->toArray(), [
                            'customer_type' => 'Dealer',
                            'scheduled' => false,
                        ]);
                    });

            
                $leads = Lead::join('customer_types', 'leads.customer_type', '=', 'customer_types.id')
                    ->where('leads.assigned_route_id', $assignedRouteId)
                    ->where(function ($query) {
                        $query->whereIn('leads.customer_type', [1, 2])
                            ->orWhere(function ($q) {
                                $q->where('leads.customer_type', 4)->where('leads.status', 'Follow Up');
                            });
                    })
                    ->get([
                        'leads.id',
                        'leads.customer_name',
                        'leads.location',
                        'customer_types.name as customer_type'
                    ])
                    ->map(function ($lead) {
                        return array_merge($lead->toArray(), ['scheduled' => false]);
                    });

                $rescheduledCustomers = collect($rescheduledCustomers ?? []);

                $customers = $dealers->merge($leads)->map(function ($customer) use ($rescheduledCustomers) {
                    $rescheduled = collect($rescheduledCustomers)->firstWhere('id', (int) $customer['id']);
                    if ($rescheduled) {
                        return array_merge($customer, ['scheduled' => true]);
                    }
                    return $customer;
                });

                $dayIndex = array_search($day, array_keys($routeMapping));
                $date = $weekStart->copy()->addDays($dayIndex)->format('d/m/y');

                $weeklyRoutes[] = [
                    'day' => $day,
                    'date' => $date,
                    'assigned_route_id' => $assignedRouteId,
                    'route_name' => $routeName,
                    'locations' => $locations,
                    'customers' => $customers->values(),
                ];
            }

            $routes = RescheduledRoute::where('employee_id', $employeeId)->get();
            $authController = new AuthController();
            foreach ($routes as $item) {
                $authController->changeNotificationStatus('assigned_routes', $item->id, "opened");
            }

            return response()->json([
                'success' => true,
                'statusCode' => 200,
                'message' => 'Weekly routes fetched successfully.',
                'data' => $weeklyRoutes,
            ], 200);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'statusCode' => 500,
                'message' => 'Error fetching weekly routes.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }
  
    public function routeReschedule(Request $request)
    {
        if (!is_array($request->input('routes'))) {
            return response()->json([
                'success' => false,
                'statusCode' => 400,
                'message' => 'Invalid data format. Expected an array of routes.',
                'data' => null
            ], 400);
        }
    
        $employeeId = $request->input('employee_id');
        if (!$employeeId) {
            return response()->json([
                'success' => false,
                'statusCode' => 400,
                'message' => 'Employee ID is required.',
                'data' => null
            ], 400);
        }
    
        $rescheduledRoutes = [];
        $alreadyRescheduledRoutes = [];
    
        $startOfWeek = Carbon::now()->startOfWeek()->format('Y-m-d');
        $endOfWeek = Carbon::now()->endOfWeek()->format('Y-m-d');
    
        foreach ($request->input('routes') as $route) {
            $validator = Validator::make($route, [
                'day' => 'required|string',
                'date' => 'required|string',
                'assigned_route_id' => 'required|integer',
                'route_name' => 'required|string',
                'locations' => 'required|array',
                'customers' => 'nullable|array',
            ]);
    
            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'statusCode' => 422,
                    'message' => 'Validation error',
                    'data' => [
                        'errors' => $validator->errors()
                    ]
                ], 422);
            }
    
            $assignDate = Carbon::createFromFormat('d/m/y', $route['date'])->format('Y-m-d');
    
            $alreadyRescheduled = RescheduledRoute::where('employee_id', $employeeId)
                ->where('assigned_route_id', $route['assigned_route_id'])
                ->whereBetween('assign_date', [$startOfWeek, $endOfWeek])
                ->exists();
    
            if ($alreadyRescheduled) {
                $alreadyRescheduledRoutes[] = [
                    'route_name' => $route['route_name'],
                    'day' => $route['day'],
                    'date' => $assignDate
                ];
                continue; 
            }
    
            $reschedule = RescheduledRoute::create([
                'employee_id' => $employeeId,  
                'day' => $route['day'],
                'assign_date' => $assignDate,
                'assigned_route_id' => $route['assigned_route_id'],
                'route_name' => $route['route_name'],
                'locations' => json_encode($route['locations']), 
                'customers' => json_encode($route['customers'] ?? []),
            ]);
    
            $rescheduledRoutes[] = $reschedule;
        }
    
        if (!empty($alreadyRescheduledRoutes)) {
            return response()->json([
                'success' => false,
                'statusCode' => 400,
                'message' => 'This Week Already Rescheduled',
                'data' => [
                    'already_rescheduled' => $alreadyRescheduledRoutes
                ]
            ], 400);
        }
    
        return response()->json([
            'success' => true,
            'statusCode' => 200,
            'message' => 'Routes rescheduled successfully.',
        ], 200);
    }
   
    public function changeRouteStatus(Request $request)
    {
        try {
            $request->validate([
                'customer_id' => 'required|integer',
                'customer_type' => 'required|string',
            ]);

            $customerId = (int) $request->customer_id;
            $customerType = $request->customer_type;

            $isDealer = ($customerType === 'Dealer');

            $rescheduledRoute = RescheduledRoute::whereRaw("JSON_CONTAINS(customers, ?)", [json_encode(['id' => $customerId])])->first();


            if (!$rescheduledRoute) {
                return response()->json([
                    'success' => false,
                    'statusCode' => 404,
                    'message' => 'Customer not found in rescheduled routes.',
                ], 404);
            }

            $customers = collect(json_decode($rescheduledRoute->customers, true)); 

            $updatedCustomers = $customers->map(function ($customer) use ($customerId, $isDealer) {
                if (isset($customer['id']) && $customer['id'] == $customerId &&
                    ($isDealer ? ($customer['customer_type'] === 'Dealer') : ($customer['customer_type'] !== 'Dealer'))) {
                    $customer['status'] = 'Completed';
                    $customer['visited_at'] = Carbon::now()->toDateTimeString();
                }
                return $customer;
            });

            $rescheduledRoute->update(['customers' => json_encode($updatedCustomers)]);

            return response()->json([
                'success' => true,
                'statusCode' => 200,
                'message' => 'Customer visit status updated successfully.',
            ], 200);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'statusCode' => 500,
                'message' => 'Error updating customer status.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function getAllRoutesByDistrict($district_id)
    {
        $routes = TripRoute::where('district_id', $district_id)->get();
        return response()->json($routes);
    }
   
    public function getRoutesByDistrict($district_id = null)
    {
        try {
            $employee = Auth::user();

            if (!$employee) {
                return response()->json([
                    'success' => false,
                    'statusCode' => 401,
                    'message' => "User not authenticated.",
                ], 401);
            }

            $query = AssignRoute::where('employee_id', $employee->id)
                ->select('id as assign_route_id', 'route_name', 'locations');

            // if ($district_id) {
            //     $query->whereHas('dealerRouteAssignments.dealer', function ($q) use ($district_id) {
            //         $q->where('district_id', $district_id);
            //     });
            // }

            $routes = $query->get();

            if ($routes->isEmpty()) {
                return response()->json([
                    'success' => false,
                    'statusCode' => 400,
                    'message' => 'No routes found for the selected district or employee.',
                    'data' => [],
                ], 400);
            }

            return response()->json([
                'success' => true,
                'statusCode' => 200,
                'message' => 'Routes fetched successfully.',
                'data' => $routes,
            ], 200);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'statusCode' => 500,
                'message' => 'Error fetching routes: ' . $e->getMessage(),
            ], 500);
        }
    }

    public function getRoutesReport(Request $request)
    {
        $employeeId = $request->input('employee_id');
        $fromDate = $request->input('from_date');
        $toDate = $request->input('to_date');

        $routes = RescheduledRoute::query()
            ->when($fromDate, function ($query) use ($fromDate) {
                $query->whereDate('assign_date', '>=', $fromDate);
            })
            ->when($toDate, function ($query) use ($toDate) {
                $query->whereDate('assign_date', '<=', $toDate);
            })
            ->when($employeeId, function ($query) use ($employeeId) {
                $query->where('employee_id', $employeeId);
            })
            ->orderBy('assign_date', 'asc')
            ->get();

        $formattedRoutes = $routes->map(function ($route) {
            $customers = json_decode($route->customers, true) ?? [];
            $customers = collect($customers)
            ->reject(function ($customer) {
                return isset($customer['customer_type'])
                    && $customer['customer_type'] === 'IHB';
            })
            ->values()
            ->toArray();

            $status = collect($customers)->contains(function ($customer) {
                return isset($customer['scheduled'])
                    && $customer['scheduled'] === true
                    && isset($customer['status'])
                    && $customer['status'] === 'Pending';
            }) ? 'Pending' : 'Completed';

            return [
                'id' => $route->id,
                'route_name' => $route->route_name,
                'locations' => json_decode($route->locations, true) ?? [],
                'day' => $route->day,
                'assign_date' => Carbon::parse($route->assign_date)->format('d/m/Y'),
                'status' => $status,
            ];
        });

        return response()->json([
            'success' => true,
            'statusCode' => 200,
            'data' => $formattedRoutes,
        ], 200);
    }
    
    public function getRouteDetails(Request $request, $routeId)
    {
        try {
            $productId = $request->input('product_id');

            $route = RescheduledRoute::with('employee')
                ->findOrFail($routeId);

            // 🔐 Optional product validation
            if ($productId) {
                $handlesProduct = Employee::where('id', $route->employee_id)
                    ->whereRaw('FIND_IN_SET(?, products)', [$productId])
                    ->exists();

                if (!$handlesProduct) {
                    return response()->json([
                        'success' => false,
                        'statusCode' => 403,
                        'message' => 'This route does not belong to the selected product.',
                    ], 403);
                }
            }

            $customers = json_decode($route->customers, true) ?? [];

            $routeSummary = collect($customers)->map(function ($customer) {
                return [
                    'customer_name' => $customer['customer_name'] ?? null,
                    'location' => $customer['location'] ?? null,
                    'customer_type' => $customer['customer_type'] ?? null,
                    'status' => $customer['status'] ?? null,
                    'completed_at' =>
                        ($customer['status'] === 'Completed' && isset($customer['visited_at']))
                            ? Carbon::parse($customer['visited_at'])->format('d/m/Y H:i:s')
                            : null,
                ];
            });

            return response()->json([
                'success' => true,
                'statusCode' => 200,
                'data' => [
                    'route_name' => $route->route_name,
                    'employee_name' => $route->employee?->name ?? 'N/A',
                    'day' => $route->day,
                    'assign_date' => Carbon::parse($route->assign_date)->format('d/m/Y'),
                    'month' => Carbon::parse($route->assign_date)->format('F'),
                    'year' => Carbon::parse($route->assign_date)->format('Y'),
                    'route_summary' => $routeSummary,
                ],
            ], 200);

        } catch (Exception $e) {
            return response()->json([
                'success' => false,
                'statusCode' => 500,
                'message' => $e->getMessage(),
            ], 500);
        }
    }
  
    public function routeIndex()
    {
        $districts = District::all(); 

        return view('sales.route.route-index', compact('districts'));
    }

    public function routeList(Request $request)
    {
        $routes = TripRoute::with('district')->orderBy('id', 'desc');

        return DataTables::of($routes)
            ->addIndexColumn()
            ->addColumn('district_name', function ($route) {
                return $route->district ? $route->district->name : 'N/A'; // Ensure district exists
            })
            ->editColumn('locations', function ($route) {
                return is_array($route->locations) ? implode(', ', $route->locations) : '';
            })
            ->addColumn('action', function ($route) {
                return '
                    <button class="btn btn-sm btn-warning editRoute" data-id="'.$route->id.'" title="Edit">
                    <i class="fa fa-edit"></i>
                </button>
                    <button class="btn btn-sm btn-danger deleteRoute" data-id="'.$route->id.'" title="Delete">
                        <i class="fa fa-trash"></i>
                    </button>';
            })
            ->rawColumns(['action'])
            ->make(true);
    }

    public function routeStore(Request $request)
    {
        $validatedData = $request->validate([
            'district' => 'required|exists:districts,id',
            'locations' => 'required|array',
        ]);
        $existingRoute = TripRoute::where('district_id', $validatedData['district'])->first();

        if ($existingRoute) {
            return response()->json(['message' => 'A route already exists for this district!'], 409);
        }

        $route = TripRoute::create([
            'district_id' => $validatedData['district'],
            'locations' => array_values($validatedData['locations']), // Store as JSON
        ]);

        return response()->json(['message' => 'Route created successfully!', 'route' => $route]);
    }

    public function editRoute($route_id)
    {
        $route = TripRoute::findOrFail($route_id);
        $districts = District::all();
        return response()->json([
            'route' => [
                'id' => $route->id,
                'district_id' => $route->district_id,
                'locations' => $route->locations ?? [],
            ],
            'districts' => $districts
        ]);
    }

    public function updateRoute(Request $request, $route_id)
    {
        $validatedData = $request->validate([
            'district' => 'required|exists:districts,id',
            'locations' => 'required|array',
        ]);
        $route = TripRoute::findOrFail($route_id);

        $existingRoute = TripRoute::where('district_id', $validatedData['district'])
            ->where('id', '!=', $route_id)
            ->first();

        if ($existingRoute) {
            return response()->json(['message' => 'A route already exists for this district!'], 409);
        }

        $route->update([
            'district_id' => $validatedData['district'],
            'locations' => array_values($validatedData['locations']), // Store as JSON
        ]);

        return response()->json(['message' => 'Route updated successfully!', 'route' => $route]);
    }

    public function deleteRoute($route_id)
    {
        try {
            $route = TripRoute::findOrFail($route_id);
            $route->delete();

            return response()->json(['success' => true, 'message' => 'Route deleted successfully!']);
        } catch (ModelNotFoundException $e) {
            return response()->json(['success' => false, 'message' => 'Route not found!'], 404);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => 'Failed to delete route!'], 500);
        }
    }
    public function assignedIndex()
    {
        $productId = ProductHelper::getSelectedProductId();
        return view('sales.route.index',compact('productId'));
    }

    public function assignedList()
    {
	     $productId = ProductHelper::getSelectedProductId();
        $routes = AssignRoute::with(['employee', 'dealers'])
                      ->whereHas('employee', function($q) use ($productId) {
                    $q->whereRaw("JSON_CONTAINS(products, ?)", ['["' . $productId . '"]']);
                })  ->get()
            ->groupBy('employee_id'); 

        $formattedRoutes = $routes->map(function ($routeGroup) {
            $firstRoute = $routeGroup->first(); 
            
            return [
                'DT_RowIndex'   => null, 
                'employee_type' => $this->getEmployeeType($firstRoute->employee->employee_type_id ?? null),
                'employee'      => $firstRoute->employee->name ?? 'N/A',

                'route_name'    => $routeGroup->map(function ($route) {
                    $dealerNames = $route->dealers->pluck('dealer_name')->implode(', ');
                    return "<strong>{$route->route_name}</strong> - {$route->locations}" 
                        . ($dealerNames ? "<br><small>Dealers: {$dealerNames}</small>" : '');
                })->implode('<hr>'),

                'action'        => '<button class="btn btn-sm btn-warning editRoute" data-id="'.$firstRoute->id.'">
                                        <i class="fa fa-edit"></i>
                                    </button>
                                    <button class="btn btn-sm btn-danger deleteRoute" data-id="'.$firstRoute->id.'">
                                        <i class="fa fa-trash"></i>
                                    </button>'
            ];
        })->values(); 

        return DataTables::of($formattedRoutes)
            ->addIndexColumn()
            ->rawColumns(['route_name', 'action']) 
            ->make(true);
    }

    private function getEmployeeType($employee_type_id)
    {
        $employeeTypes = [
            1 => 'Sales Executive',
            2 => 'Area Sales Officer',
            3 => 'District Sales Manager',
            4 => 'Regional Sales Manager',
	    5 => 'Sales Manager',
	    7 => 'Area Sales Manager',
        ];
        return $employeeTypes[$employee_type_id] ?? 'Unknown';
    }

    public function storeAssignedRoute(Request $request)
    {
        $request->validate([
            'employee_type_id' => 'required|integer',
            'employee_id' => 'required|exists:employees,id',
            'routes' => 'required|array|max:6',
            'routes.*.route_name' => 'required|string|max:255',
            'routes.*.locations' => 'nullable|array',
            'routes.*.locations.*' => 'nullable|string',
            'routes.*.dealers' => 'nullable|array',
            'routes.*.dealers.*' => 'nullable|integer|exists:dealers,id',
        ]);

        $employeeTypeId = $request->employee_type_id;
        $employeeId = $request->employee_id;

        // Check for duplicate assignment (same employee + type)
        $existing = AssignRoute::where('employee_type_id', $employeeTypeId)
            ->where('employee_id', $employeeId)
            ->exists();

        if ($existing) {
            return response()->json(['message' => 'This employee already has assigned routes!'], 422);
        }

        foreach ($request->routes as $route) {
            $routeName = $route['route_name'];
            $locations = isset($route['locations']) && is_array($route['locations'])
                ? implode(', ', $route['locations'])
                : '';

            // Create assigned route entry
            $assignedRoute = AssignRoute::create([
                'employee_type_id' => $employeeTypeId,
                'employee_id' => $employeeId,
                'route_name' => $routeName,
                'locations' => $locations,
            ]);

            // Save linked dealers for that route (if provided)
            if (isset($route['dealers']) && is_array($route['dealers'])) {
                foreach ($route['dealers'] as $dealerId) {
                    DealerRouteAssignment::create([
                        'assign_route_id' => $assignedRoute->id,
                        'dealer_id' => $dealerId,
                        'location' => null, // optional, can fill if you store location per dealer
                    ]);
                }
            }
        }

        return response()->json(['message' => 'Assigned routes stored successfully!']);
    }

    public function editAssignedRoute($id)
    {
        $route = AssignRoute::findOrFail($id);

        // Get all assigned routes for this employee
        $assignedRoutes = AssignRoute::where('employee_type_id', $route->employee_type_id)
            ->where('employee_id', $route->employee_id)
            ->with('dealerAssignments')
            ->get();

        $formattedData = [
            'id' => $route->id,
            'employee_type_id' => $route->employee_type_id,
            'employee_id' => $route->employee_id,
            'routes' => $assignedRoutes->map(function ($r) {
                return [
                    'route_name' => $r->route_name,
                    'locations' => !empty($r->locations) ? explode(', ', $r->locations) : [],
                    'dealers' => $r->dealerAssignments->pluck('dealer_id')->toArray(),
                ];
            }),
        ];

        return response()->json(['success' => true, 'data' => $formattedData]);
    }

    public function updateAssignedRoute(Request $request, $id)
    {
        $request->validate([
            'employee_type_id' => 'required|integer',
            'employee_id' => 'required|exists:employees,id',
            'routes' => 'required|array|max:6',
            'routes.*.route_name' => 'required|string|max:255',
            'routes.*.locations' => 'nullable|array',
            'routes.*.locations.*' => 'nullable|string',
            'routes.*.dealers' => 'nullable|array',
            'routes.*.dealers.*' => 'nullable|integer|exists:dealers,id',
        ]);

        $employeeTypeId = $request->employee_type_id;
        $employeeId = $request->employee_id;

        // Find reference route
        $existingRoute = AssignRoute::findOrFail($id);

        // Delete all current routes & dealer assignments for this employee
        $existingRoutes = AssignRoute::where('employee_type_id', $existingRoute->employee_type_id)
            ->where('employee_id', $existingRoute->employee_id)
            ->get();

        foreach ($existingRoutes as $route) {
            DealerRouteAssignment::where('assign_route_id', $route->id)->delete();
            $route->delete();
        }

        // Recreate updated routes
        foreach ($request->routes as $route) {
            $routeName = $route['route_name'];
            $locations = isset($route['locations']) && is_array($route['locations'])
                ? implode(', ', $route['locations'])
                : '';

            $assignedRoute = AssignRoute::create([
                'employee_type_id' => $employeeTypeId,
                'employee_id' => $employeeId,
                'route_name' => $routeName,
                'locations' => $locations,
            ]);

            // Reinsert dealer assignments
            if (isset($route['dealers']) && is_array($route['dealers'])) {
                foreach ($route['dealers'] as $dealerId) {
                    DealerRouteAssignment::create([
                        'assign_route_id' => $assignedRoute->id,
                        'dealer_id' => $dealerId,
                    ]);
                }
            }
        }

        return response()->json(['message' => 'Assigned routes updated successfully!']);
    }
   
    public function deleteAssignedRoute($id)
    {
        $route = AssignRoute::findOrFail($id);

        // Get all routes for this employee
        $employeeRoutes = AssignRoute::where('employee_type_id', $route->employee_type_id)
            ->where('employee_id', $route->employee_id)
            ->get();

        foreach ($employeeRoutes as $r) {
            DealerRouteAssignment::where('assign_route_id', $r->id)->delete();
            $r->delete();
        }

        return response()->json(['message' => 'All assigned routes for this employee deleted successfully!']);
    }

    public function getDistricts()
    {
        return response()->json(District::select('id', 'name')->get());
    }

    public function getEmployees(Request $request)
    {
        $productId = ProductHelper::getSelectedProductId(); 
        $employees = Employee::where('district_id', $request->district_id)
            ->where('employee_type_id', $request->employee_type_id)
             ->whereRaw("JSON_CONTAINS(products, ?)", ['["' . $productId . '"]'])
            ->select('id', 'name')
            ->get();

        return response()->json($employees);
    }
    public function getLocations(Request $request)
    {
        $routes = TripRoute::where('district_id', $request->district_id)->get();

        $locations = $routes->pluck('locations')->flatten()->unique()->values();

        return response()->json($locations);
    }

    public function getEmployeesByType(Request $request)
    {
	    $productId = ProductHelper::getSelectedProductId(); //push
        return Employee::where('employee_type_id', $request->employee_type_id)
		->whereRaw("JSON_CONTAINS(products, ?)", ['["' . $productId . '"]'])//push
    		->select('id', 'name')
            ->get();
    }

    public function getAllLocations()
    {
        return TripRoute::pluck('locations')->flatten()->unique()->values();
    }

    public function getDealersByLocations(Request $request)
    {
        return Dealer::whereIn('location', $request->locations)
            ->select('id', 'dealer_name')
            ->get();
    }

    public function tracking(){     
        $districts = District::where("status","1")->orderBy("name","asc")->get(); 
        $designations = EmployeeType::orderBy("type_name","asc")->get();
        $employees = Employee::select("id","employee_code","name","employee_type_id","district_id")->orderBy("name","asc")->get(); 
        return view('sales.tracking.index', compact('districts','designations','employees'));
    }

    public function trackingData(Request $request)
    {
        $request->validate([
            'district_id'    => 'nullable',
            'designation_id' => 'nullable',
            'employee_id'    => 'nullable',
            'date'           => 'required|date',
        ]);

        $date = $request->date;

        $districtId    = $request->district_id;
        $designationId = $request->designation_id;
        $employeeId    = $request->employee_id;

        $startDate = Carbon::parse($date)->startOfDay();
        $endDate   = Carbon::parse($date)->endOfDay();

        $routes   = [];
        $timeline = [];

        /*
        |--------------------------------------------------------------------------
        | 1. LEADS
        |--------------------------------------------------------------------------
        */

        $leads = Lead::query()
            ->whereBetween('created_at', [$startDate, $endDate])
            ->when($employeeId, function ($query) use ($employeeId) {
                $query->where('created_by', $employeeId);
            })
            ->when($districtId, function ($query) use ($districtId) {
                $query->where('district_id', $districtId);
            })
            ->get();

        foreach ($leads as $lead) {

            /*
            | Map
            */
            if (
                !empty($lead->latitude) &&
                !empty($lead->longitude)
            ) {

                $routes[] = [
                    'lat'         => $lead->latitude,
                    'lng'         => $lead->longitude,
                    'type'        => 'lead',
                    'title'       => 'Lead',
                    'description' => $lead->customer_name ?? 'Lead',
                    'time'        => $lead->created_at,
                ];
            }

            /*
            | Timeline
            */
            $timeline[] = [
                'type'        => 'lead',
                'time'        => Carbon::parse($lead->created_at)->format('h:i A'),
                'title'       => 'Lead Captured',
                'location'    => $lead->customer_name ?? 'Lead',
                'description' => 'New lead created',
                'sort_time'   => Carbon::parse($lead->created_at)->timestamp,
            ];
        }


        /*
        |--------------------------------------------------------------------------
        | 2. INFLUENCER VISITS
        |--------------------------------------------------------------------------
        */

        $influencerVisits = InfluencerVisit::query()
            ->whereBetween('created_at', [$startDate, $endDate])
            ->when($employeeId, function ($query) use ($employeeId) {
                $query->where('created_by', $employeeId);
            })
            ->get();

        foreach ($influencerVisits as $visit) {

            /*
            | Map
            */
            if (
                !empty($visit->latitude) &&
                !empty($visit->longitude)
            ) {

                $routes[] = [
                    'lat'         => $visit->latitude,
                    'lng'         => $visit->longitude,
                    'type'        => 'influencer',
                    'title'       => 'Influencer Visit',
                    'description' => $visit->influencer_name ?? 'Influencer Visit',
                    'time'        => $visit->created_at,
                ];
            }

            /*
            | Timeline
            */
            $timeline[] = [
                'type'        => 'influencer',
                'time'        => Carbon::parse($visit->created_at)->format('h:i A'),
                'title'       => 'Influencer Visit',
                'location'    => $visit->influencer_name ?? 'Influencer Visit',
                'description' => 'Influencer visited',
                'sort_time'   => Carbon::parse($visit->created_at)->timestamp,
            ];
        }


        /*
        |--------------------------------------------------------------------------
        | 3. DEALER VISITS
        |--------------------------------------------------------------------------
        */

        $dealerVisits = DealerVisit::with('dealer')
            ->whereBetween('created_at', [$startDate, $endDate])
            ->when($employeeId, function ($query) use ($employeeId) {
                $query->where('created_by', $employeeId);
            })
            ->get();

        foreach ($dealerVisits as $visit) {

            /*
            | Map
            */
            if (
                !empty($visit->latitude) &&
                !empty($visit->longitude)
            ) {

                $routes[] = [
                    'lat'         => $visit->latitude,
                    'lng'         => $visit->longitude,
                    'type'        => 'dealer',
                    'title'       => 'Dealer Visit',
                    'description' => $visit->dealer->dealer_name ?? 'Dealer Visit',
                    'time'        => $visit->created_at,
                ];
            }

            /*
            | Timeline
            */
            $timeline[] = [
                'type'        => 'dealer',
                'time'        => Carbon::parse($visit->created_at)->format('h:i A'),
                'title'       => 'Dealer Visit',
                'location'    => $visit->dealer->dealer_name ?? 'Dealer Visit',
                'description' => 'Dealer visited',
                'sort_time'   => Carbon::parse($visit->created_at)->timestamp,
            ];
        }


        /*
        |--------------------------------------------------------------------------
        | 4. ORDERS
        |--------------------------------------------------------------------------
        */

        $orders = Order::with('dealer')
            ->whereBetween('created_at', [$startDate, $endDate])
            ->when($employeeId, function ($query) use ($employeeId) {
                $query->where('created_by', $employeeId);
            })
            ->get();

        foreach ($orders as $order) {

            /*
            | Map
            */
            if (
                !empty($order->latitude) &&
                !empty($order->longitude)
            ) {

                $routes[] = [
                    'lat'         => $order->latitude,
                    'lng'         => $order->longitude,
                    'type'        => 'order',
                    'title'       => 'Order',
                    'description' => $order->dealer->dealer_name ?? 'Order',
                    'time'        => $order->created_at,
                ];
            }

            /*
            | Timeline
            */
            $timeline[] = [
                'type'        => 'order',
                'time'        => Carbon::parse($order->created_at)->format('h:i A'),
                'title'       => 'Order Taken',
                'location'    => $order->dealer->dealer_name ?? 'Order',
                'description' => 'Order created',
                'sort_time'   => Carbon::parse($order->created_at)->timestamp,
            ];
        }


        /*
        |--------------------------------------------------------------------------
        | 5. ACTIVITIES
        |--------------------------------------------------------------------------
        */

        $activities = Activity::with('activityType')
            ->whereBetween('updated_at', [$startDate, $endDate])
            ->where('employee_id', $employeeId)
            ->get();

        foreach ($activities as $activity) {

            /*
            | Map
            */
            if (
                !empty($activity->latitude) &&
                !empty($activity->longitude)
            ) {

                $routes[] = [
                    'lat'         => $activity->latitude,
                    'lng'         => $activity->longitude,
                    'type'        => 'activity',
                    'title'       => 'Activity',
                    'description' => $activity->activityType->name ?? 'Activity',
                    'time'        => $activity->updated_at,
                ];
            }

            /*
            | Timeline
            */
            $timeline[] = [
                'type'        => 'activity',
                'time'        => Carbon::parse($activity->updated_at)->format('h:i A'),
                'title'       => 'Activity',
                'location'    => $activity->activityType->name ?? 'Activity',
                'description' => 'Activity performed',
                'sort_time'   => Carbon::parse($activity->updated_at)->timestamp,
            ];
        }


        /*
        |--------------------------------------------------------------------------
        | 6. COMMITMENTS / COMMENTS
        |--------------------------------------------------------------------------
        */

        $comments = OutstandingPaymentCommitment::whereBetween(
                'committed_date',
                [$startDate, $endDate]
            )
            ->when($employeeId, function ($query) use ($employeeId) {
                $query->where('employee_id', $employeeId);
            })
            ->get();

        foreach ($comments as $comment) {

            /*
            | Map
            */
            if (
                !empty($comment->latitude) &&
                !empty($comment->longitude)
            ) {

                $routes[] = [
                    'lat'         => $comment->latitude,
                    'lng'         => $comment->longitude,
                    'type'        => 'commitment',
                    'title'       => 'Commitment',
                    'description' => $comment->comment ?? 'Comment',
                    'time'        => $comment->created_at,
                ];
            }

            /*
            | Timeline
            */
            $timeline[] = [
                'type'        => 'commitment',
                'time'        => Carbon::parse($comment->created_at)->format('h:i A'),
                'title'       => 'Commitment',
                'location'    => $comment->comment ?? 'Commitment',
                'description' => 'Payment commitment',
                'sort_time'   => Carbon::parse($comment->created_at)->timestamp,
            ];
        }


        
        
        /*
        |--------------------------------------------------------------------------
        | ATTENDANCE
        |--------------------------------------------------------------------------
        */

        $Attendance = Attendance::whereBetween(
                'date',
                [$startDate, $endDate]
            )
            ->when($employeeId, function ($query) use ($employeeId) {
                $query->where('employee_id', $employeeId);
            })
            ->first();

        if ($Attendance && !empty($Attendance->punch_in)) {

            $punchInDateTime = Carbon::parse(
                $date . ' ' . $Attendance->punch_in
            );

            if (!empty($Attendance->latitude) && !empty($Attendance->longitude)) {
                    $routes[] = [
                        'lat'         => $Attendance->latitude,
                        'lng'         => $Attendance->longitude,
                        'type'        => 'punch_in',
                        'title'       => 'Punch In',
                        'description' => 'Punch In',
                        'time'        => $Attendance->punch_in,
                    ];
            }
            $timeline[] = [
                'type'        => 'punch_in',
                'time'        => $punchInDateTime->format('h:i A'),
                'title'       => 'Punch In',
                'description' => '',
                'sort_time'   => $punchInDateTime->timestamp,
            ];
        }


        /*
        |--------------------------------------------------------------------------
        | PUNCH OUT
        |--------------------------------------------------------------------------
        */

        if ($Attendance && !empty($Attendance->punch_out)) {

            $punchInOutDateTime = Carbon::parse(
                $date . ' ' . $Attendance->punch_out
            );

            if (!empty($Attendance->latitude_out) && !empty($Attendance->longitude_out)) {
                    $routes[] = [
                        'lat'         => $Attendance->latitude_out,
                        'lng'         => $Attendance->longitude_out,
                        'type'        => 'punch_out',
                        'title'       => 'Punch Out',
                        'description' => 'Punch Out',
                        'time'        => $Attendance->punch_out,
                    ];
            }
            $timeline[] = [
                'type'        => 'punch_out',
                'time'        => $punchInOutDateTime->format('h:i A'),
                'title'       => 'Punch Out',
                'description' => '',
                'sort_time'   => $punchInOutDateTime->timestamp,
            ];
        }

        /*
        |--------------------------------------------------------------------------
        | Sort Route By Time
        |--------------------------------------------------------------------------
        */

        usort($routes, function ($a, $b) {

            return strtotime($a['time'] ?? '00:00:00')
                <=> strtotime($b['time'] ?? '00:00:00');

        });
        $travelledKm = $this->calculateTravelledKm($routes);
        /*
        |--------------------------------------------------------------------------
        | Sort Timeline
        |--------------------------------------------------------------------------
        */

        usort($timeline, function ($a, $b) {

            return ($a['sort_time'] ?? 0)
                <=> ($b['sort_time'] ?? 0);

        });
        

        /*
        |--------------------------------------------------------------------------
        | Remove Internal sort_time
        |--------------------------------------------------------------------------
        */

        $timeline = array_map(function ($item) {

            unset($item['sort_time']);

            return $item;

        }, $timeline);


        /*
        |--------------------------------------------------------------------------
        | Counts
        |--------------------------------------------------------------------------
        */

        $counts = [
            'leads'              => 0,
            'influencers'        => 0,
            'dealers'            => 0,
            'orders'             => 0,
            'activities'         => 0,
            'comments'           => 0,
            'commitments'        => 0,
            'travelled_km'        => $travelledKm ?? 0,
            'punch_in'           => $Attendance->punch_in ?? "",
            'punch_out'          => $Attendance->punch_out ?? "",
            'total_active_hours' => $Attendance->total_active_hours ?? "",
        ];


        foreach ($routes as $route) {

            switch ($route['type']) {

                case 'lead':
                    $counts['leads']++;
                    break;

                case 'influencer':
                    $counts['influencers']++;
                    break;

                case 'dealer':
                    $counts['dealers']++;
                    break;

                case 'order':
                    $counts['orders']++;
                    break;

                case 'activity':
                    $counts['activities']++;
                    break;

                case 'comment':
                    $counts['comments']++;
                    break;
            }
        }


        /*
        |--------------------------------------------------------------------------
        | Commitment Count
        |--------------------------------------------------------------------------
        */

        $counts['commitments'] = $comments->count();


        /*
        |--------------------------------------------------------------------------
        | Response
        |--------------------------------------------------------------------------
        */

        return response()->json([

            'success'  => true,

            'date'     => $date,

            'counts'   => $counts,

            'routes'   => $routes,

            'timeline' => $timeline,

        ]);
    }

   private function calculateTravelledKm(array $routes)
    {
        /*
        |--------------------------------------------------------------------------
        | 1. Keep only valid coordinates
        |--------------------------------------------------------------------------
        */

        $locations = collect($routes)
            ->filter(function ($route) {

                return isset($route['lat'], $route['lng'])
                    && is_numeric($route['lat'])
                    && is_numeric($route['lng'])
                    && (float) $route['lat'] != 0
                    && (float) $route['lng'] != 0;
            })
            ->values();

        /*
        |--------------------------------------------------------------------------
        | 2. Need at least 2 locations
        |--------------------------------------------------------------------------
        */

        if ($locations->count() < 2) {

            \Log::warning('Travelled KM: Not enough valid locations', [
                'total_routes' => count($routes),
                'valid_locations' => $locations->count(),
                'routes' => $routes,
            ]);

            return 0;
        }

        /*
        |--------------------------------------------------------------------------
        | 3. Origin
        |--------------------------------------------------------------------------
        */

        $first = $locations->first();

        $origin = [
            'location' => [
                'latLng' => [
                    'latitude'  => (float) $first['lat'],
                    'longitude' => (float) $first['lng'],
                ],
            ],
        ];

        /*
        |--------------------------------------------------------------------------
        | 4. Destination
        |--------------------------------------------------------------------------
        */

        $last = $locations->last();

        $destination = [
            'location' => [
                'latLng' => [
                    'latitude'  => (float) $last['lat'],
                    'longitude' => (float) $last['lng'],
                ],
            ],
        ];

        /*
        |--------------------------------------------------------------------------
        | 5. Intermediate locations
        |--------------------------------------------------------------------------
        */

        $intermediates = [];

        if ($locations->count() > 2) {

            foreach ($locations->slice(1, $locations->count() - 2) as $location) {

                $intermediates[] = [
                    'location' => [
                        'latLng' => [
                            'latitude'  => (float) $location['lat'],
                            'longitude' => (float) $location['lng'],
                        ],
                    ],
                ];
            }
        }

        /*
        |--------------------------------------------------------------------------
        | 6. Log request before calling Google
        |--------------------------------------------------------------------------
        */

        \Log::info('Google Routes API Request', [
            'location_count' => $locations->count(),
            'origin' => $origin,
            'destination' => $destination,
            'intermediates_count' => count($intermediates),
        ]);

        /*
        |--------------------------------------------------------------------------
        | 7. Google Routes API
        |--------------------------------------------------------------------------
        */

        $response = Http::timeout(30)
            ->withHeaders([
                'Content-Type' => 'application/json',
                'X-Goog-Api-Key' => config('services.google_maps.key'),
                'X-Goog-FieldMask' => 'routes.distanceMeters,routes.polyline.encodedPolyline',
            ])
            ->post(
                'https://routes.googleapis.com/directions/v2:computeRoutes',
                [
                    'origin' => $origin,

                    'destination' => $destination,

                    'intermediates' => $intermediates,

                    'travelMode' => 'DRIVE',

                    'routingPreference' => 'TRAFFIC_UNAWARE',

                    'optimizeWaypointOrder' => false,
                ]
            );

        /*
        |--------------------------------------------------------------------------
        | 8. Log COMPLETE Google response
        |--------------------------------------------------------------------------
        */

        \Log::info('Google Routes API Response', [
            'status' => $response->status(),
            'successful' => $response->successful(),
            'body' => $response->body(),
        ]);

        /*
        |--------------------------------------------------------------------------
        | 9. HTTP error
        |--------------------------------------------------------------------------
        */

        if (!$response->successful()) {

            \Log::error('Google Routes API HTTP Error', [
                'status' => $response->status(),
                'body' => $response->body(),
            ]);

            return 0;
        }

        /*
        |--------------------------------------------------------------------------
        | 10. Decode JSON
        |--------------------------------------------------------------------------
        */

        $data = $response->json();

        /*
        |--------------------------------------------------------------------------
        | 11. Check Google returned routes
        |--------------------------------------------------------------------------
        */

        if (
            !is_array($data) ||
            !isset($data['routes']) ||
            !is_array($data['routes']) ||
            empty($data['routes'])
        ) {

            \Log::error('Google Routes API: No route returned', [
                'status' => $response->status(),
                'body' => $response->body(),
                'decoded_response' => $data,
                'origin' => $origin,
                'destination' => $destination,
                'intermediates' => $intermediates,
            ]);

            return 0;
        }

        /*
        |--------------------------------------------------------------------------
        | 12. Get distance
        |--------------------------------------------------------------------------
        */

        $distanceMeters = $data['routes'][0]['distanceMeters'] ?? null;

        if ($distanceMeters === null) {

            \Log::error('Google Routes API: distanceMeters missing', [
                'response' => $data,
            ]);

            return 0;
        }

        /*
        |--------------------------------------------------------------------------
        | 13. Convert meters -> KM
        |--------------------------------------------------------------------------
        */

        $distanceKm = $distanceMeters / 1000;

        /*
        |--------------------------------------------------------------------------
        | 14. Final log
        |--------------------------------------------------------------------------
        */

        \Log::info('Travelled KM Calculated', [
            'distance_meters' => $distanceMeters,
            'distance_km' => round($distanceKm, 2),
            'location_count' => $locations->count(),
        ]);

        return round($distanceKm, 2);
    }

    public function trackingDetails(Request $request)
    {
        $request->validate([
            'type'          => 'required|in:lead,influencer,dealer,order,activity,commitment',
            'district_id'   => 'nullable',
            'designation_id'=> 'nullable',
            'employee_id'   => 'nullable',
            'date'          => 'required|date',
        ]);

        $type = $request->type;
        $date = $request->date;

        $startDate = Carbon::parse($date)->startOfDay();
        $endDate   = Carbon::parse($date)->endOfDay();

        $employeeId = $request->employee_id;
        $districtId = $request->district_id;

        $data = collect();


        /*
        |--------------------------------------------------------------------------
        | Leads
        |--------------------------------------------------------------------------
        */

        if ($type === 'lead') {

            $data = Lead::with("customerType")

                ->whereBetween(
                    'created_at',
                    [$startDate, $endDate]
                )

                ->when($employeeId, function ($query) use ($employeeId) {

                    $query->where(
                        'created_by',
                        $employeeId
                    );

                })

                ->when($districtId, function ($query) use ($districtId) {

                    $query->where(
                        'district_id',
                        $districtId
                    );

                })

                ->orderBy('created_at')

                ->get()

                ->map(function ($lead) {

                    return [
                        'customer_name' => $lead->customer_name ?? '-',
                        'time' => $lead->created_at
                        ? Carbon::parse($lead->created_at)
                        ->format('h:i A')
                        : '-',
                        'customer_type' => $lead->customerType->name ?? '-',
                        // 'location' => trim(
                        //     ($lead->latitude ?? '') .
                        //     ', ' .
                        //     ($lead->longitude ?? ''),
                        
                        //)
                    ];

                });

        }


        /*
        |--------------------------------------------------------------------------
        | Influencer
        |--------------------------------------------------------------------------
        */

        elseif ($type === 'influencer') {

            $data = InfluencerVisit::query()

                ->whereBetween(
                    'created_at',
                    [$startDate, $endDate]
                )

                ->when($employeeId, function ($query) use ($employeeId) {

                    $query->where(
                        'created_by',
                        $employeeId
                    );

                })

                ->orderBy('created_at')

                ->get()

                ->map(function ($visit) {

                    return [
                        'influencer_name' =>
                            $visit->influencer_name ?? '-',

                        'time' => $visit->created_at
                            ? Carbon::parse($visit->created_at)
                                ->format('h:i A')
                            : '-',

                        // 'location' => trim(
                        //     ($visit->latitude ?? '') .
                        //     ', ' .
                        //     ($visit->longitude ?? '')
                        // )
                    ];

                });

        }


        /*
        |--------------------------------------------------------------------------
        | Dealer
        |--------------------------------------------------------------------------
        */

        elseif ($type === 'dealer') {

            $data = DealerVisit::with('dealer')

                ->whereBetween(
                    'created_at',
                    [$startDate, $endDate]
                )

                ->when($employeeId, function ($query) use ($employeeId) {

                    $query->where(
                        'created_by',
                        $employeeId
                    );

                })

                ->orderBy('created_at')

                ->get()

                ->map(function ($visit) {

                    return [
                        'dealer_name' =>
                            $visit->dealer->dealer_name ?? '-',

                        'time' => $visit->created_at
                            ? Carbon::parse($visit->created_at)
                                ->format('h:i A')
                            : '-',

                        
                    ];

                });

        }


        /*
        |--------------------------------------------------------------------------
        | Orders
        |--------------------------------------------------------------------------
        */

        elseif ($type === 'order') {

            $data = Order::with('dealer')

                ->whereBetween(
                    'created_at',
                    [$startDate, $endDate]
                )

                ->when($employeeId, function ($query) use ($employeeId) {

                    $query->where(
                        'created_by',
                        $employeeId
                    );

                })

                ->orderBy('created_at')

                ->get()

                ->map(function ($order) {

                    return [
                        'dealer_name' =>
                            $order->dealer->dealer_name ?? '-',

                        'order_number' =>
                           'OD00' .$order->id ?? '-',
                        'time' => $order->created_at
                            ? Carbon::parse($order->created_at)
                                ->format('h:i A')
                            : '-',
                    ];

                });

        }


        /*
        |--------------------------------------------------------------------------
        | Activities
        |--------------------------------------------------------------------------
        */

        elseif ($type === 'activity') {

            $data = Activity::with('activityType','dealer')

                ->whereBetween(
                    'assigned_date',
                    [$startDate, $endDate]
                )

                ->when($employeeId, function ($query) use ($employeeId) {

                    $query->where(
                        'employee_id',
                        $employeeId
                    );

                })

                ->orderBy('assigned_date')

                ->get()

                ->map(function ($activity) {

                    return [
                        'activity_name' =>
                            $activity->activityType->name ?? 'Activity',

                        'time' => $activity->assigned_date
                            ? Carbon::parse($activity->assigned_date)
                                ->format('h:i A')
                            : '-',

                        'dealer' =>  $activity->dealer->dealer_name ?? 'NA',
                    ];

                });

        }


        /*
        |--------------------------------------------------------------------------
        | Commitments
        |--------------------------------------------------------------------------
        */

        elseif ($type === 'commitment') {

            $data = OutstandingPaymentCommitment::with("outstandingPayment.dealer")

                ->whereBetween(
                    'committed_date',
                    [$startDate, $endDate]
                )

                ->when($employeeId, function ($query) use ($employeeId) {

                    $query->where(
                        'employee_id',
                        $employeeId
                    );

                })

                ->orderBy('committed_date')

                ->get()

                ->map(function ($commitment) {

                    return [
                        'comment' =>
                            $commitment->comment ?? '-',
                        'dealer' =>
                            $commitment->outstandingPayment->dealer->dealer_name ?? '-',

                        // 'committed_date' =>
                        //     $commitment->committed_date
                        //         ? Carbon::parse(
                        //             $commitment->committed_date
                        //         )->format('d-m-Y')
                        //         : '-',

                        'time' => $commitment->committed_date
                            ? Carbon::parse(
                                $commitment->committed_date
                            )->format('d-m-Y')
                            : '-',
                    ];

                });

        }


        return response()->json([
            'success' => true,
            'data' => $data->values(),
        ]);
    }

    public function overview(){
        $districts = District::where("status","1")->orderBy("name","asc")->get(); 
        $designations = EmployeeType::orderBy("type_name","asc")->get();
        $customertype = CustomerType::select("id","name")->orderBy("name","asc")->get(); 
        return view('sales.tracking.overview', compact('districts','designations','customertype'));
    }

    public function overviewDetials(Request $request)
    {
        $request->validate([
            'district_id'     => 'nullable',
            'designation_id'  => 'nullable',
            'customertype_id' => 'nullable',
            'duration'        => 'required|in:today,yesterday,this_week,this_month,3_month',
        ]);

        /*
        |--------------------------------------------------------------------------
        | Get Filters
        |--------------------------------------------------------------------------
        */

        $districtId     = $request->district_id;
        $designationId  = $request->designation_id;
        $customerTypeId = $request->customertype_id;
        $duration       = $request->duration;
        


        /*
        |--------------------------------------------------------------------------
        | Calculate Date Range
        |--------------------------------------------------------------------------
        */

        switch ($duration) {

            case 'yesterday':

                $fromDate = Carbon::yesterday()->startOfDay();
                $toDate   = Carbon::yesterday()->endOfDay();

                break;


            case 'this_week':

                $fromDate = Carbon::now()->startOfWeek();
                $toDate   = Carbon::now()->endOfWeek();

                break;


            case 'this_month':

                $fromDate = Carbon::now()->startOfMonth();
                $toDate   = Carbon::now()->endOfMonth();

                break;


            case '3_month':

                $fromDate = Carbon::now()
                    ->subMonths(2)
                    ->startOfMonth();

                $toDate = Carbon::now()->endOfMonth();

                break;


            case 'today':

            default:

                $fromDate = Carbon::today()->startOfDay();
                $toDate   = Carbon::today()->endOfDay();

                break;
        }


        /*
        |--------------------------------------------------------------------------
        | Points Collection
        |--------------------------------------------------------------------------
        */

        $points = collect();


        /*
        |--------------------------------------------------------------------------
        | 1. LEADS
        |--------------------------------------------------------------------------
        */

        $leadsQuery = Lead::with("createdBy.employeeType","customerType")
            ->whereBetween('created_at', [
                $fromDate,
                $toDate
            ]);

        if (!empty($districtId)) {
            $leadsQuery->where(
                'district_id',
                $districtId
            );
        }
        if (!empty($designationId)) {
            $leadsQuery->whereHas('createdBy.employeeType', function ($query) use ($designationId) {
                $query->where('id', $designationId);
            });
        }
        if (!empty($customerTypeId)) {
            $leadsQuery->whereHas('customerType', function ($query) use ($customerTypeId) {
                $query->where('id', $customerTypeId);
            });

        }


        $leads = $leadsQuery->get();


        foreach ($leads as $lead) {

            if (
                is_numeric($lead->latitude) &&
                is_numeric($lead->longitude)
            ) {

                $points->push([
                    'lat'           => (float) $lead->latitude,
                    'lng'           => (float) $lead->longitude,
                    'date'           => $lead->created_at,
                    'name'           => $lead->customer_name,
                    'activity_type' => 'Lead',
                ]);
            }
        }


        /*
        |--------------------------------------------------------------------------
        | 2. INFLUENCER VISITS
        |--------------------------------------------------------------------------
        */

        $influencerQuery = InfluencerVisit::with("createdBy.employeeType")
            ->whereBetween('created_at', [
                $fromDate,
                $toDate
            ]);

        if (!empty($districtId)) {

            $influencerQuery->where(
                'district_id',
                $districtId
            );
        }
               
        if (!empty($designationId)) {
            $influencerQuery->whereHas('createdBy.employeeType', function ($query) use ($designationId) {
                $query->where('id', $designationId);
            });
        }

       

        $influencerVisits = $influencerQuery->get();

        if(empty($customerTypeId)) {        
            foreach ($influencerVisits as $visit) {

                if (
                    is_numeric($visit->latitude) &&
                    is_numeric($visit->longitude)
                ) {

                    $points->push([
                        'lat'           => (float) $visit->latitude,
                        'lng'           => (float) $visit->longitude,
                        'date'           => $visit->created_at,
                        'name'           => $visit->influencer_name,
                        'activity_type' => 'Influencer Visit',
                    ]);
                }
            }
        }


        /*
        |--------------------------------------------------------------------------
        | 3. DEALER VISITS
        |--------------------------------------------------------------------------
        */

        $dealerVisitsQuery = DealerVisit::with("dealer.district",'createdBy.employeeType')
            ->whereBetween('created_at', [
                $fromDate,
                $toDate
            ]);

        
        if (!empty($districtId)) {
            $dealerVisitsQuery->whereHas('dealer.district', function ($query) use ($districtId) {
                $query->where('id', $districtId);
            });
        }       
        if (!empty($designationId)) {
            $dealerVisitsQuery->whereHas('createdBy.employeeType', function ($query) use ($designationId) {
                $query->where('id', $designationId);
            });
        }
        

        $dealerVisits = $dealerVisitsQuery->get();

        if (empty($customerTypeId)) {        
            foreach ($dealerVisits as $visit) {

                if (
                    is_numeric($visit->latitude) &&
                    is_numeric($visit->longitude)
                ) {

                    $points->push([
                        'lat'           => (float) $visit->latitude,
                        'lng'           => (float) $visit->longitude,
                        'date'           => $visit->created_at,
                        'name'           => $visit->dealer->dealer_name,
                        'activity_type' => 'Dealer Visit',
                    ]);
                }
            }
        }


        /*
        |--------------------------------------------------------------------------
        | 4. ORDERS
        |--------------------------------------------------------------------------
        */

        $ordersQuery = Order::with('dealer.district',"createdBy.employeeType","customerType")
            ->whereBetween('created_at', [
                $fromDate,
                $toDate
            ]);


        
        if (!empty($districtId)) {
            $ordersQuery->whereHas('dealer.district', function ($query) use ($districtId) {
                $query->where('id', $districtId);
            });
        }       
        if (!empty($designationId)) {
            $ordersQuery->whereHas('createdBy.employeeType', function ($query) use ($designationId) {
                $query->where('id', $designationId);
            });
        }

        if (!empty($customerTypeId)) {
            // dd($customerTypeId);
            $ordersQuery->where(
                'customer_type_id',
                $customerTypeId
            );
        }

        $orders = $ordersQuery->get();
         
        foreach ($orders as $order) {

            if (
                is_numeric($order->latitude) &&
                is_numeric($order->longitude)
            ) {

                $points->push([
                    'lat'           => (float) $order->latitude,
                    'lng'           => (float) $order->longitude,
                    'name' => "OD00".$order->id,
                    'date' => $order->created_at,
                    'activity_type' => 'Order',
                ]);
            }
        }
        /*
        |--------------------------------------------------------------------------
        | 5. ACTIVITIES
        |--------------------------------------------------------------------------
        */

        $activitiesQuery = Activity::with('dealer.district','employee.employeeType','activityType')
            ->whereBetween('updated_at', [
                $fromDate,
                $toDate
            ]);
        
        if (!empty($districtId)) {
            $activitiesQuery->whereHas('dealer.district', function ($query) use ($districtId) {
                $query->where('id', $districtId);
            });
        }       
        if (!empty($designationId)) {            
            $activitiesQuery->whereHas('employee.employeeType', function ($query) use ($designationId) {
                $query->where('id', $designationId);
            });
        }

        if (empty($customerTypeId)) {        
            $activities = $activitiesQuery->get();
            foreach ($activities as $activity) {

                if (
                    is_numeric($activity->latitude) &&
                    is_numeric($activity->longitude)
                ) {

                    $activityType = optional(
                        $activity->activityType
                    )->name;


                    $points->push([
                        'lat'           => (float) $activity->latitude,
                        'lng'           => (float) $activity->longitude,
                        'name' => $activityType,
                        'date' => $activity->updated_at,
                        'activity_type' => 'Activity',
                    ]);
                }
            }
        }


        /*
        |--------------------------------------------------------------------------
        | 6. PAYMENT COMMITMENTS
        |--------------------------------------------------------------------------
        */

        $commitmentsQuery = OutstandingPaymentCommitment::with('employee',"outstandingPayment.dealer")
            ->whereBetween('committed_date', [
                $fromDate->toDateString(),
                $toDate->toDateString()
            ]);


         if (!empty($districtId)) {
            $commitmentsQuery->whereHas('employee.district', function ($query) use ($districtId) {
                $query->where('id', $districtId);
            });
        }       
        if (!empty($designationId)) {            
            $commitmentsQuery->whereHas('employee.employeeType', function ($query) use ($designationId) {
                $query->where('id', $designationId);
            });
        }


        $commitments = $commitmentsQuery->get();
        if (empty($customerTypeId)) {
        
            foreach ($commitments as $commitment) {

                if (
                    is_numeric($commitment->latitude) &&
                    is_numeric($commitment->longitude)
                ) {

                    $points->push([
                        'lat'           => (float) $commitment->latitude,
                        'lng'           => (float) $commitment->longitude,
                        'name' => $commitment->outstandingPayment->dealer->dealer_name,
                        'date' => $commitment->committed_date,
                        'activity_type' => 'Payment Commitment',
                    ]);
                }
            }
        }


        /*
        |--------------------------------------------------------------------------
        | Remove Invalid Coordinates
        |--------------------------------------------------------------------------
        */

        $points = $points
            ->filter(function ($point) {

                return
                    isset($point['lat']) &&
                    isset($point['lng']) &&
                    is_numeric($point['lat']) &&
                    is_numeric($point['lng']);
            })
            ->values();


        /*
        |--------------------------------------------------------------------------
        | Response
        |--------------------------------------------------------------------------
        */

        return response()->json([
            'success' => true,
            'points'  => $points,
        ]);
    }


}
